<?php

    $packetThreshold = "15000";
    $packet = "5000";

    $interface = trim(shell_exec("ip route show default | awk '/default/ {print $5}'"));
    $filename = (__DIR__ . "/" . basename(__FILE__));
    $perms = fileperms($filename);

    if ($perms !== false) {

        $octalPerms = substr(sprintf('%o', $perms), -4);

        if (!($octalPerms === '0777')) {

            echo("Файл " . $filename . " не имеет прав доступа 777" . "\n");

            exit();

        }

    } else {

        echo("Не удалось получить права доступа к файлу " . $filename . "\n");

        exit();

    }

    if (empty(shell_exec('which iptables'))) {

        echo("iptables не установлен на сервере - apt install iptables -y." . "\n");

        exit();

    } else if (empty(shell_exec('which mpstat'))) {

        echo("sysstat не установлен на сервере - apt install sysstat -y." . "\n");

        exit();

    } else if (empty(shell_exec('which tcpdump'))) {

        echo("tcpdump не установлен на сервере - apt install tcpdump -y." . "\n");

        exit();

    } else if (empty(shell_exec('which ufw'))) {

        echo("ufw не установлен на сервере - apt install ufw -y && sudo ufw enable." . "\n");

        exit();

    }

    echo("Защита активирована и ожидает атаки." . "\n");

    while (true) {

        $cpuUsage = shell_exec("mpstat 1 1 | awk '/all/ {print 100 - \$NF}'");

        $rxPacketsInitial = shell_exec("cat /sys/class/net/$interface/statistics/rx_packets");

        sleep(5);

        $rxPacketsFinal = shell_exec("cat /sys/class/net/$interface/statistics/rx_packets");
        $packetsPerSecond = $rxPacketsFinal - $rxPacketsInitial;

        if ($cpuUsage > 75 || $packetsPerSecond > $packetThreshold) {

            $getip = exec('tcpdump -i ' . $interface . ' -n -s 0 -c ' . $packetThreshold . ' | awk \'{print $3}\'');

            $explode = explode('.', $getip);
            $attackIp = ($explode[0] . '.' . $explode[1] . '.' . $explode[2] . '.' . $explode[3]);

            $output = shell_exec("sudo tcpdump -n -c 100 -i " . $interface . " src " . $attackIp);

            $lines = explode("\n", $output);
            $count = 0;

            foreach ($lines as $line) {

                if (preg_match('/(\d+) packets captured/', $line, $matches)) {

                    $count = $matches[1];

                }

            }

            if ($attackIp) {

                if ($count < $packet) {
                    
                    if (!isset($ip) == $attackIp) {

                        unset($ip);

                        $message = "Обнаружена атака от IP " . $attackIp . "\n";

                        $array = [

                            'key' => 'da84nqdat',
                            'text' => $message,
                            'id' => '6080490144',

                        ];

                        $ch = curl_init('https://api.whost.su/tg/API/message.php');

                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                        curl_setopt($ch, CURLOPT_HEADER, false);
                        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
                        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                        curl_setopt($ch, CURLOPT_FORBID_REUSE, false);
                        curl_setopt($ch, CURLOPT_FRESH_CONNECT, false);

                        curl_exec($ch);

                        curl_close($ch);

                        echo($message);

                    }

                    $ip = $attackIp;

                }

            }

        }

    }

?>