<?php

    include __DIR__ . '/../host/config.php';
    include __DIR__ . '/../host/src/payment.php';

    $url = ((!empty($_SERVER['HTTPS'])) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];

    $data = isset($_GET['data']) ? $_GET['data'] : '';

    function onDecode($text, $key, $cipher) {

        $base64_decode = base64_decode($text);
        $ivlen = openssl_cipher_iv_length($cipher);
        $iv = substr($base64_decode, 0, $ivlen);
        $hmac = substr($base64_decode, $ivlen, $sha2len = 32);
        $raw = substr($base64_decode, $ivlen + $sha2len);
        $decode = openssl_decrypt($raw, $cipher, $key, $options = OPENSSL_RAW_DATA, $iv);
        $calcmac = hash_hmac('sha256', $raw, $key, $as_binary = true);

        if (hash_equals($hmac, $calcmac)) {

            return $decode;

        }

        return false;

    }

    $decode = onDecode(base64_decode($data), $config['secret_word'], "AES-128-CBC");

    if ($data == null and $data == "") {

        header("Location: " . $config['url_home']);
        
        exit();

    } else if (json_decode($decode, true)['id'] == null and json_decode($decode, true)['id'] == "") {

        header('Content-Type: application/json');

        print_R (

            json_encode (

                array (

                    "message" => "Не верно переданы параметры",
                    "success" => false,

                ),

                JSON_UNESCAPED_UNICODE

            )

        );

        return false;

    }

?>

<html lang="ru">
<head>

    <meta charset="utf-8">
    <meta name="google" content="notranslate">
    <link rel="icon" href="<?php echo($config['url_home']); ?>/img/tg.svg">
    <link href="../assets/css/text.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>PayNel - Выберите платёжную систему,</title>
    <link href="./assets/css/style.css" rel="stylesheet">

</head>
<body>

    <div class="InvoicePage_wrapper__uyJ5q">
        <div class="InvoicePage_container__+Ah1X">
            <div class="ant-spin-nested-loading">
                <div class="InvoicePage_payment__NQ9xT">
                    <div class="InvoicePayment_wrapper__1d8+u">

                        <div class="InvoiceTitle_title__v87xT">
                            <a href="<?php echo($url . $_SERVER['REQUEST_URI']); ?>"><img class="zvezda" style="pointer-events: none;" src="<?php echo($config['url_home']); ?>/img/zvezda.png" width="64px" alt="logo"></a>
                            <div><span>Покупка подписки</span></div>
                            <div class="InvoiceInfo_top__8rtNH"><span>Оплата товара на сумму <?php echo(json_decode($decode, true)['suma']); ?>,00 ₽</span></div>
                        </div>

                        <div class="ant-spin-nested-loading">
                            <div class="ant-spin-container">
                                <div class="Services_services__2zqs2">

                                    <!---

                                    <a class="Service_body__k2CyQ" href="./yoomoney/api.php?create&data=<?php echo($data); ?>">
                                        <div class="Service_logo__QaoYX"><img style="pointer-events: none;" src="<?php echo($config['url_home']); ?>/img/yoo-money.svg" alt=""></div>
                                        <div>
                                            <div><span class="Service_title__f5of+"><font color="#252129">Платёжная система - YooMoney</font></span></div>
                                            <div><span>Комиссия 3.2%</span></div>
                                        </div>
                                    </a>

                                    -->

                                    <a class="Service_body__k2CyQ" href="./aaio/api.php?create&data=<?php echo($data); ?>">
                                        <div class="Service_logo__QaoYX"><img style="pointer-events: none;" src="<?php echo($config['url_home']); ?>/img/pay_aaio.png" alt=""></div>
                                        <div>
                                            <div><span class="Service_title__f5of+"><font color="#252129">Платёжная система - Aaio</font></span></div>
                                            <div><span>Комиссия 1.7%</span></div>
                                        </div>
                                    </a>

                                    <a class="Service_body__k2CyQ" href="./gidpay/api.php?create&data=<?php echo($data); ?>">
                                        <div class="Service_logo__QaoYX"><img style="pointer-events: none;" src="<?php echo($config['url_home']); ?>/img/g-pay.png" alt=""></div>
                                        <div>
                                            <div><span class="Service_title__f5of+"><font color="#252129">Платёжная система - GidPay</font></span></div>
                                            <div><span>Комиссия 0.8%</span></div>
                                        </div>
                                    </a>
                                    
                                    <a class="Service_body__k2CyQ" href="<?php echo($config['pay']['vk']); ?>" target="_blank">
                                        <div class="Service_logo__QaoYX"><img style="pointer-events: none;" src="<?php echo($config['url_home']); ?>/img/vk.svg" alt=""></div>
                                        <div>
                                            <div><span class="Service_title__f5of+"><font color="#252129">Произвольная платёжная система</font></span></div>
                                            <div><span>Комиссия 1.3%</span></div>
                                        </div>
                                    </a>

                                    <a class="Service_body__k2CyQ" href="<?php echo($config['pay']['tg']); ?>" target="_blank">
                                        <div class="Service_logo__QaoYX"><img style="pointer-events: none;" src="<?php echo($config['url_home']); ?>/img/tg.svg" alt=""></div>
                                        <div>
                                            <div><span class="Service_title__f5of+"><font color="#252129">Произвольная платёжная система</font></span></div>
                                            <div><span>Комиссия 4%</span></div>
                                        </div>
                                    </a>

                                    <a onclick="closeWindow()">
                                      <center>
                                        <div data-text="Отменить платёж">
                                            <span style="display: inline-block; margin-top: 10px; text-decoration: none;">Отменить платёж</span>
                                        </div><br>
                                      </center>
                                    </a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<style>

img.zvezda {
  animation: 1s linear 0s normal none infinite running zvezda;
  -webkit-animation: 3s linear 0s normal none infinite running zvezda;
}

@keyframes zvezda {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

</style>

<script> 

  document.oncontextmenu = cmenu; function cmenu() {

    return false; 

  }

  const closeWindow = () => {

    window.close();
    document.location.href = '<?php echo(json_decode($decode, true)['url_app']); ?>';


  };

</script>

</body>
</html>