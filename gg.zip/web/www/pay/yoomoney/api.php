<?php

    include __DIR__ . '/../../host/config.php';
    include __DIR__ . '/../../api/tg/config.php';

    $url = ((!empty($_SERVER['HTTPS'])) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];

    $data = isset($_GET["data"]) ? $_GET["data"] : '';

    function onDecode($text, $key, $cipher) {

        $base64_decode = base64_decode($text);
        $ivlen = openssl_cipher_iv_length($cipher);
        $iv = substr($base64_decode, 0, $ivlen);
        $hmac = substr($base64_decode, $ivlen, $sha2len = 32);
        $raw = substr($base64_decode, $ivlen + $sha2len);
        $decode = openssl_decrypt($raw, $cipher, $key, $options = OPENSSL_RAW_DATA, $iv);
        $calcmac = hash_hmac('sha256', $raw, $key, $as_binary = true);

        if (hash_equals($hmac, $calcmac)) {

            return $decode;

        }

        return false;

    }

    $decode = onDecode(base64_decode($data), $config['secret_word'], "AES-128-CBC");

    if (isset($_GET['create'])) {

        if (json_decode($decode, true)['key'] == null and json_decode($decode, true)['key'] == "") {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя использовать аргумент 'key' пустым или не заданным",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!(json_decode($decode, true)['key'] == $config['secret_word'])) {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Ключ '" . $key . "' не прошёл проверку",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        }

        $data = array (

            "receiver" => json_decode($decode, true)['receiver_id'],
            "label" => "Оплата товара на сумму " . json_decode($decode, true)['suma'] . " руб - ID: " . json_decode($decode, true)['id'],
            "quickpay-form" => "button",
            "paymentType" => $type,
            "sum" => json_decode($decode, true)['suma'],
            "successURL" => "https://paynel.ru/yoomoney/api.php?check&data=" . $data,

        );

        $url = 'https://yoomoney.ru/quickpay/confirm';

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        $headers = [

            "Content-Type: application/json",

        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);

        curl_close($ch);

        $operation_id = substr(strstr($response, '='), 1, strlen($response));

        $get_url = str_replace("Found. Redirecting to ", "", $response);

        header("Location: " . $get_url);

        exit();

        return true;

    } else if (isset($_GET['check'])) {

        $url = 'https://yoomoney.ru/api/operation-history';

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);

        $fileContents = file_get_contents(__DIR__ . "/" . "token.json");

        $token = json_decode($fileContents, true)['token'];

        $headers = [

            "Authorization: Bearer " . $token,
            "Content-Type: application/x-www-form-urlencoded",

        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);

        $json_decode = json_decode($response, true);

        curl_close($ch);

        $decode = onDecode(base64_decode($data), $config['secret_word'], "AES-128-CBC");

        if ($data == null and $data == "") {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя использовать аргумент 'data' пустым или не заданным",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (json_decode($decode, true)['id'] == null and json_decode($decode, true)['id'] == "") {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Не верно переданы параметры",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!(json_decode($decode, true)['key'] == $config['secret_word'])) {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Не верно передан параметр Key",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!($json_decode['operations'][0]['status'] == "success")) {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Неверный статус платежа",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!($json_decode['operations'][0]['label'] == "Оплата товара на сумму " . json_decode($decode, true)['suma'] . " руб - ID: " . json_decode($decode, true)['id'])) {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Неверное описание платежа",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        }

        $url = "https://api.telegram.org/bot" . $get_config['token'] . "/getChatMember?chat_id=" . json_decode($decode, true)['id'] . "&user_id=" . json_decode($decode, true)['id'];

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        $data = json_decode($response, true);

        $get_username = isset($data['result']['user']['username']) && !empty($data['result']['user']['username']) ? $data['result']['user']['username'] : "Не найдена";

        curl_close($ch);

        $data = array (

            "id" => json_decode($decode, true)['telegram_id'],
            "text" => $get_config['tag'] . " - У вас купили товар? Проверьте платёжную систему, которая подключена к вашему магазину.\n\n - Айди пользователя: " . json_decode($decode, true)['id'] . "\n - Имя пользователя: " . $get_username . "\n - Сумма платежа: " . $config['suma'] . " руб\n - Дата и время покупки: " . date("d.m.Y - H:i") . "\n\nМы работаем на благо обществу - PayNel.",
            "key" => $config['secret_word'],

        );

        $url = 'https://api.whost.su/tg/API/message.php';

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

        curl_exec($ch);

        curl_close($ch);

        $array = array (

            "user_id" => json_decode($decode, true)['id'],
            "method" => "add",
            "key" => json_decode($decode, true)['key'],

        );

        $ch = curl_init("https://api.whost.su/tg/API/users.php");

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, false);

        curl_exec($ch);

        curl_close($ch);

        header("Location: " . $config['url_home']);

        exit();

        return true;

    } else {

        header('Content-Type: application/json');

        print_R (

            json_encode (

                array (

                    "message" => "Нельзя использовать аргумент 'create' или же 'check' не заданным",
                    "success" => false,

                ),

                JSON_UNESCAPED_UNICODE

            )

        );

        return false;

    }

?>