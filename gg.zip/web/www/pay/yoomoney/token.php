<?php

    include __DIR__ . '/../../host/config.php';

    header('Content-Type: application/json');

    $config_array = array (

        "client_id" => "2E1DFD4604ED3B8FAE9B006D87D533F1C4ECBBED7470CC17FCD29D3763EA6E96",
        "redirect_uri" => "https://paynel.ru/yoomoney/token.php",
        "token_config" => "token.json",

    );

    $key = isset($_GET['key']) ? $_GET['key'] : '';

    if (isset($_GET["get"])) {

        if ($key == null and $key == "") {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя использовать аргумент 'key' пустым или не заданным",
                        "status" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!($config['secret_word'] == $key)) {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Ключ '" . $key . "' не прошёл проверку",
                        "status" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        }

        $data = array (

            "client_id" => $config_array['client_id'],
            "response_type" => "code",
            "redirect_uri" => $config_array['redirect_uri'],
            "scope" => "account-info operation-history operation-details payment-p2p",
            "instance_name" => "PayNel",

        );

        $url = 'https://yoomoney.ru/oauth/authorize';

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

        $response = curl_exec($ch);

        curl_close($ch);

        $get_url = str_replace("Found. Redirecting to ", "", $response);

        header("Location: " . $get_url);

        exit();

    } else if (isset($_GET['code'])) {

        header('Content-Type: application/json');

        $data = array (

            "client_id" => $config_array['client_id'],
            "grant_type" => "authorization_code",
            "redirect_uri" => $config_array['redirect_uri'],
            "code" => $_GET['code'],

        );

        $url = 'https://yoomoney.ru/oauth/token';

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

        $response = curl_exec($ch);

        curl_close($ch);

        $json_decode = json_decode($response, true);

        $token = $json_decode['access_token'];

        $fileContents = file_get_contents(__DIR__ . "/" . $config_array['token_config']);

        $config = json_decode($fileContents, true);

        foreach ($config as $key => $info) {

            if ($key == $token) {

                print_R (

                    json_encode (

                        array (

                            "message" => "Данный токен уже есть в базе",
                            "status" => false,

                        ),

                    )

                );

                return false;

            }

        }

        if ($token == null and $token == "") {

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя использовать аргумент 'token' пустым или не заданным",
                        "status" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        }

        $config = array (

            'token' => $token,

        );

        $newFileContents = json_encode($config);

        file_put_contents(__DIR__ . "/" . $config_array['token_config'], $newFileContents);

        print_R (

            json_encode (

                array (

                    "message" => "Токен успешно добавлена в базу",
                    "status" => true,

                ),

            )

        );

        return true;

    } else {

        print_R (

            json_encode (

                array (

                    "message" => "Страница предназначена для администраций",
                    "status" => false,

                ),

                JSON_UNESCAPED_UNICODE

            )

        );

        return false;

    }

?>