<?php

    session_start();

    include __DIR__ . '/../../host/config.php';
    include __DIR__ . '/../../api/tg/config.php';

    $url = ((!empty($_SERVER['HTTPS'])) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];

    $data = isset($_GET["data"]) ? $_GET["data"] : '';

    function onDecode($text, $key, $cipher) {

        $base64_decode = base64_decode($text);
        $ivlen = openssl_cipher_iv_length($cipher);
        $iv = substr($base64_decode, 0, $ivlen);
        $hmac = substr($base64_decode, $ivlen, $sha2len = 32);
        $raw = substr($base64_decode, $ivlen + $sha2len);
        $decode = openssl_decrypt($raw, $cipher, $key, $options = OPENSSL_RAW_DATA, $iv);
        $calcmac = hash_hmac('sha256', $raw, $key, $as_binary = true);

        if (hash_equals($hmac, $calcmac)) {

            return $decode;

        }

        return false;

    }

    $decode = onDecode(base64_decode($data), $config['secret_word'], "AES-128-CBC");

    if (isset($_GET['create'])) {

        if (json_decode($decode, true)['key'] == null and json_decode($decode, true)['key'] == "") {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя использовать аргумент 'key' пустым или не заданным",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!(json_decode($decode, true)['key'] == $config['secret_word'])) {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Ключ '" . $key . "' не прошёл проверку",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        }

        $merchant_id = json_decode($decode, true)['aaio_id'];
        $amount = json_decode($decode, true)['suma'];
        $currency = 'RUB'; // Валюта заказа
        $secret = json_decode($decode, true)['aaio_secret'];
        $order_id = json_decode($decode, true)['id'] + time();
        $sign = hash('sha256', implode(':', [$merchant_id, $amount, $currency, $secret, $order_id]));
        $desc = "Оплата товара на сумму " . json_decode($decode, true)['suma'] . " руб - ID: " . json_decode($decode, true)['id'];
        $lang = 'ru'; // Язык формы

        header("Location: " . "https://aaio.so/merchant/pay?" . http_build_query([

            'merchant_id' => $merchant_id,
            'amount' => $amount,
            'currency' => $currency,
            'order_id' => $order_id,
            'sign' => $sign,
            'desc' => $desc,
            'lang' => $lang,

        ]));

        $_SESSION["key"] = json_decode($decode, true)['key'];
        $_SESSION["admin_id"] = json_decode($decode, true)['telegram_id'];
        $_SESSION["id"] = json_decode($decode, true)['id'];

        exit();

        return true;

    } else if (isset($_GET['check'])) {

        header('Content-Type: application/json');

        $secret = 'fa154ebedf398249eb6f1cfadad9d452';
        $currency = 'RUB';

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

            die("wrong request method");

        }

        if ($_POST['currency'] !== $currency) {

            die("wrong currency");

        }

        function getIP() {

            $ip = $_SERVER['REMOTE_ADDR'];

            if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {

                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];

            }

            if (isset($_SERVER['HTTP_X_REAL_IP'])) {

                $ip = $_SERVER['HTTP_X_REAL_IP'];

            }

            if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {

                $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];

            }

            $explode = explode(',', $ip);

            if (count($explode) > 1) {

                $ip = $explode[0];

            }

            return trim($ip);

        }

        $ctx = stream_context_create([

            'http' => [

                'timeout' => 10

            ]

        ]);

        $ips = json_decode(file_get_contents('https://aaio.io/api/public/ips', false, $ctx));

        if (isset($ips->list) && !in_array(getIP(), $ips->list)) {

            die("hacking attempt");

        }

        $sign = hash('sha256', implode(':', [$_POST['merchant_id'], $_POST['amount'], $_POST['currency'], $secret, $_POST['order_id']]));

        if (!hash_equals($_POST['sign'], $sign)) {

            die("wrong sign");

        }

        $url = "https://api.telegram.org/bot" . $get_config['token'] . "/getChatMember?chat_id=" . $_SESSION["id"] . "&user_id=" . $_SESSION["id"];

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        $data = json_decode($response, true);

        $get_username = isset($data['result']['user']['username']) && !empty($data['result']['user']['username']) ? $data['result']['user']['username'] : "Не найдена";

        curl_close($ch);

        $data = array (

            "id" => $_SESSION["admin_id"],
            "text" => $get_config['tag'] . " - У вас купили товар? Проверьте платёжную систему, которая подключена к вашему магазину.\n\n - Айди пользователя: " . $_SESSION["id"] . "\n - Имя пользователя: " . $get_username . "\n - Сумма платежа: " . $config['suma'] . " руб\n - Дата и время покупки: " . date("d.m.Y - H:i") . "\n\nМы работаем на благо обществу - PayNel.",
            "key" => $config['secret_word'],

        );

        $url = 'https://api.whost.su/tg/API/message.php';

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

        curl_exec($ch);

        curl_close($ch);

        $array = array (

            "user_id" => $_SESSION["id"],
            "method" => "add",
            "key" => $_SESSION["key"],

        );

        $ch = curl_init("https://api.whost.su/tg/API/users.php");

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, false);

        curl_exec($ch);

        curl_close($ch);

        unset($_SESSION["key"]);
        unset($_SESSION["id"]);
        unset($_SESSION["admin_id"]);

        session_unset();
        session_destroy();

        header("Location: " . json_decode($decode_info, true)['url_app']);

        exit();

        return true;

    } else {

        header('Content-Type: application/json');

        print_R (

            json_encode (

                array (

                    "message" => "Нельзя использовать аргумент 'create' или же 'check' не заданным",
                    "success" => false,

                ),

                JSON_UNESCAPED_UNICODE

            )

        );

        return false;

    }

?>