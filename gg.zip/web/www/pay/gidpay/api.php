<?php

    session_start();

    include __DIR__ . '/../../host/config.php';
    include __DIR__ . '/../../api/tg/config.php';

    $url = ((!empty($_SERVER['HTTPS'])) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];

    $data = isset($_GET["data"]) ? $_GET["data"] : '';

    function onDecode($text, $key, $cipher) {

        $base64_decode = base64_decode($text);
        $ivlen = openssl_cipher_iv_length($cipher);
        $iv = substr($base64_decode, 0, $ivlen);
        $hmac = substr($base64_decode, $ivlen, $sha2len = 32);
        $raw = substr($base64_decode, $ivlen + $sha2len);
        $decode = openssl_decrypt($raw, $cipher, $key, $options = OPENSSL_RAW_DATA, $iv);
        $calcmac = hash_hmac('sha256', $raw, $key, $as_binary = true);

        if (hash_equals($hmac, $calcmac)) {

            return $decode;

        }

        return false;

    }

    $decode = onDecode(base64_decode($data), $config['secret_word'], "AES-128-CBC");

    if (isset($_GET['create'])) {

        if (json_decode($decode, true)['key'] == null and json_decode($decode, true)['key'] == "") {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя использовать аргумент 'key' пустым или не заданным",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!(json_decode($decode, true)['key'] == $config['secret_word'])) {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Ключ '" . $key . "' не прошёл проверку",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        }

        $_SESSION['data'] = $data;

        $data = [

            'transaction_id' => json_decode($decode, true)['id'] + time(),
            "public_key" => json_decode($decode, true)['gidpay_key'],
            "shop_id" => json_decode($decode, true)['gidpay_id'],
            "amount" => json_decode($decode, true)['suma'],
            'method' => 'full',
            "currency" => "RUB",

        ];

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, "https://gidpay.ru/api/pay");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data, '', '&'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $headers = [

            "Content-Type: application/x-www-form-urlencoded",

        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = json_decode(curl_exec($ch), true);

        if ($response['status'] == 'error') {

            die($response['error']);

        }

        curl_close($ch);

        header("Location: " . $response['success']['url']);

        exit();

        return true;

    } else if (isset($_GET['order_id'])) {

        $decode_info = onDecode(base64_decode($_SESSION['data']), $config['secret_word'], "AES-128-CBC");

        if (json_decode($decode_info, true)['id'] == null and json_decode($decode_info, true)['id'] == "") {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Не верно переданы параметры",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!(json_decode($decode_info, true)['key'] == $config['secret_word'])) {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Не верно передан параметр Key",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        }

        if ($_SESSION['data'] == null and $_SESSION['data'] == "") {

            header('Content-Type: application/json');

            print_R (

                json_encode (

                    array (

                        "message" => "Не удалось обработать ответ",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        }

        $url = "https://api.telegram.org/bot" . $get_config['token'] . "/getChatMember?chat_id=" . json_decode($decode_info, true)['id'] . "&user_id=" . json_decode($decode_info, true)['id'];

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        $data = json_decode($response, true);

        $get_username = isset($data['result']['user']['username']) && !empty($data['result']['user']['username']) ? $data['result']['user']['username'] : "Не найдена";

        curl_close($ch);

        $data = array (

            "id" => json_decode($decode_info, true)['telegram_id'],
            "text" => $get_config['tag'] . " - У вас купили товар? Проверьте платёжную систему, которая подключена к вашему магазину.\n\n - Айди пользователя: " . json_decode($decode_info, true)['id'] . "\n - Имя пользователя: " . $get_username . "\n - Сумма платежа: " . $config['suma'] . " руб\n - Дата и время покупки: " . date("d.m.Y - H:i") . "\n\nМы работаем на благо обществу - PayNel.",
            "key" => $config['secret_word'],

        );

        $ch = curl_init("https://api.whost.su/tg/API/message.php");

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

        curl_exec($ch);

        curl_close($ch);

        $array = array (

            "user_id" => json_decode($decode_info, true)['id'],
            "method" => "add",
            "key" => json_decode($decode_info, true)['key'],

        );

        $ch = curl_init("https://api.whost.su/tg/API/users.php");

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, false);

        curl_exec($ch);

        curl_close($ch);

        unset($_SESSION['data']);

        session_unset();
        session_destroy();

        header("Location: " . json_decode($decode_info, true)['url_app']);

        exit();

        return true;

    } else {

        header('Content-Type: application/json');

        print_R (

            json_encode (

                array (

                    "message" => "Нельзя использовать аргумент 'create' или же 'order_id' не заданным",
                    "success" => false,

                ),

                JSON_UNESCAPED_UNICODE

            )

        );

        return false;

    }

?>