<?php

  $allowedHosts = ['whost.su', 'animesha.ru'];

  if (!in_array($_SERVER['HTTP_HOST'], $allowedHosts)) {

  	header('X-Frame-Options: DENY');
    header("Location: https://google.com/");

    exit();

  }

  define('INCLUDE_CHECK', true);
  header('Content-Type: text/html;charset=UTF-8');
  
  include "./config.php";
  include "./src/post.php";

?>

<html lang="en">
<head>
	
	<meta charset="utf-8">
	<meta name="google" content="notranslate">
	<link rel="icon" href="./img/tg.svg">
	<meta name="description">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=5">
	<meta http-equiv="Content-Security-Policy" content="img-src https://*; child-src 'none';" />
	<link href="./assets/css/text.css" rel="stylesheet">
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
	<script src="/assets/js/t.min.js"></script>
	<script src="https://kit.fontawesome.com/43a291c5b2.js" crossorigin="anonymous"></script>
	<title><?php echo($config)['name']; ?> - Покупка</title>
	<link href="./assets/css/main.css" rel="stylesheet">

</head>

  <body style="background-image: url('./img/bg.svg');">

  	<div id="root">
  		<div class="App">

  			<header class="App-header">

  				<div class="App-logo" style="pointer-events: none;">

  					<img style="border-radius: 100px;" src="./img/fireball.png" width="40px" alt="">
  					<p><div class="text hero glitch layers" data-text="<?php echo($config)['name']; ?>"><?php echo($config)['name']; ?> <div class="loader__message" style="color: #9e9e9e; font-size: 14px; sans-serif;"></div></div></p>

  				</div>

  		    <div class="App-nav">
  					<ul>
  						<li>

  							<a style="text-decoration: none;" href="<?php echo($config)['url_gitbook']; ?>">
  								<i class="fa-solid fa-book"></i> <strong class="glitch layers Plan hero" data-text="<?php echo(base64_encode($_SERVER['HTTP_X_FORWARDED_FOR'])); ?>">GitBook</strong>
  							</a>
  						
  						</li>
  					</ul>
  				</div>

				</header>

				<div class="Purchase-premium">
					<div class="Purchase-premium-container" style="border-radius: 40px 10px">

						<p class="Title" style="pointer-events: none;">
							<span>
								<img src="./img/circle-info-solid.svg" alt="Важная информация" width="19px"> Покупка <a class="blue" style="text-decoration: none;"><?php echo($config)['name']; ?></a>
							</span>
						</p>

						<form class="Purchase-premium-form" method="POST">
							<div class="Purchase-premium-form-vk">

								<label style="pointer-events: none;">
									<img src="./img/tg.svg" width="18px" alt="TG" style="vertical-align: sub;"> <b id="t">Ваш Telegram ID:</b>
								</label>

								<div class="Purchase-premium-form-vk-content">

									<input name="tg" id="tg" type="number" maxlength="32" placeholder="Напишите ваш Telegram ID" required="">

									<button type="submit" class="btn" disabled="" name='buy'><i class="fa-solid fa-cart-shopping"></i></button>

									<p><br><input value="" id="form" required="" type="checkbox"/>
										<label class="newsletter-wide__text" for="form">
											<span>Согласен на покупку подписки.</span>
										</label>
									</p>

								</div>
							</div>

						</form>

					</div>

						<div class="About-premium">
							<center><p class="Title">Информация,</p></center>
							<div class="About-premium-content">

								<span>
									<strong class="glitch layers Plan hero" data-text="ID">ID</strong> - Чтобы узнать, свой ID, нужно зайти в наш Telegram канал и написать /getid. Данный ID нужно написать на сайте, после чего вас автоматически после оплаты добавят в базу Telegram бота - <a style="text-decoration: none;" href="./bot/redirect">Telegram.</a>
								</span><br><br>

								<span class="Premium-content">
									<strong class="glitch layers Plan blue hero" data-text="PRIVATE">PRIVATE</strong> - Мы не собираем никакой информации о своих клиентах. Мы понимаем, если она утечёт, фирмы могут подать на нас в суд. И это затронет не только нас, но и наших клиентов.
								</span><br>
								
								<span>
									<br><strong class="glitch layers red hero" data-text="INFO">INFO</strong> - Перед покупкой откройте личные сообщения
									<br>Чтобы администрация смогла с вами связаться и выдать вам товар если произойдёт ошибка так же проверьте правильно ли вы указали ID своего Telegram аккаунта.
							  </span><br>

							</div>
						</div>

						<div class="Footer-container">
							<div class="Footer-content">
								<div class="Payment-methods">

									<div class="Payment-method" style="pointer-events: none;"><img src="./img/bitcoin.svg" alt="Bitcoin"></div>
									<div class="Payment-method" style="pointer-events: none;"><img src="./img/tron.png" alt="Tron"></div>
									<div class="Payment-method" style="pointer-events: none;"><img src="./img/monero.png" alt="Monero"></div>
									<div class="Payment-method" style="pointer-events: none;"><img src="./img/megafon.svg" alt="Megafon"></div>
									<div class="Payment-method" style="pointer-events: none;"><img src="./img/sberbank.svg" alt="Sberbank"></div>
									<div class="Payment-method" style="pointer-events: none;"><img src="./img/visa.svg" alt="Visa"></div>
									<div class="Payment-method" style="pointer-events: none;"><img src="./img/mcard.svg" alt="Mcard"></div>
									<div class="Payment-method" style="pointer-events: none;"><img src="./img/mir.svg" alt="Mir"></div>

								</div><hr>
							</div>
						</div>

					</div>
				</div>
			</div>
		</body>

<script type="text/javascript">

(function() {

  var loaderMessages = [

    'Сервер прямо RIP?',
    'У тебя есть 10 секунд!',
    'Я слышу DDoS-атаки?',
    'Начнём. БДСМ-DDoS!',
    'Сервер уже взбешен!',

  ];

  var loaderMessageElement = document.querySelector('.loader__message');
  if (!loaderMessageElement) return;
  var messageIndex = Math.floor(Math.random() * loaderMessages.length);
  loaderMessageElement.innerHTML = loaderMessages[messageIndex];

})();

form.onchange = function() {

  var button = document.body.getElementsByClassName('btn')[0];
  if (button.disabled) button.disabled = false;
  else button.disabled = true;

}

$('#form').on('change', function() {

  if ($(this).is(':checked')) $('.btn').attr('disabled', false);
  else $('.btn').attr('disabled', true);

});

</script>

<style>

input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {

    /* display: none; <- Crashes Chrome on hover */
    -webkit-appearance: none;
    margin: 0; /* <-- Apparently some margin are still there even though it's hidden */

}

</style>

<script type="text/javascript">

document.onkeydown = function(e) {

	if (event.keyCode == 123) {

		return false;

	}

	if (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {

		return false;

	}

	if (e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {

		 return false;

	}

	if (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {

		 return false;

	}

	if (e.ctrlKey && e.keyCode == 'S'.charCodeAt(0)) {

		 return false;

	}

}

document.ondragstart = noselect;
document.onselectstart = noselect;
document.oncontextmenu = noselect;

function noselect() {

	return false;

}

document.oncontextmenu = cmenu; function cmenu() { 

  return false;

}

</script>

<style type="text/css">

.noselect {

    -moz-user-select: none;
    -webkit-user-select: none;
    -ms-user-select: none;
    -o-user-select: none;
    user-select: none;

}

body, html {

	overflow-x: hidden;

}

input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {

    -webkit-appearance: none;
    margin: 0;

}

input[type=number] {

    -moz-appearance:textfield;
}

</style>

<script type="text/javascript">

  $('body').on('input', 'input[type="number"][maxlength]', function() {

  	if (this.value.length > this.maxLength) {

  		this.value = this.value.slice(0, this.maxLength);

  	}

  });

</script>

<script type="text/javascript">

$(function() {
	
 $('#t').t({
  
  delay: 0,                   // start delay in seconds [default:0]
  speed: 75,                  // typing speed (ms) [default:50]
  speed_vary: false,          // 'human like' speed variation [default:false]
  beep: false,                 // beep while typing (Web Audio API) [default:false]
  mistype: 4,                 // mistype rate: 1:N per char [default:false]
  locale: 'ru',               // keyboard layout (to fit mistype); supported: 'en' (english) or 'de' (german) [default:'en']
  
  caret: true,            // caret content; can be html too [default:true (\u258e)]
  blink: true,                // blink-interval in ms; if TRUE, speed*3  [default:true]
  blink_perm: true,          // permanent blinking? if FALSE, caret blinks only on delay/pause/finish [default:false]
  repeat: 0,                  // repeat typing: if TRUE, infinite or N times [default:0]
  tag: 'span',                // wrapper tag (.t-container, .t-caret) [default:'span']
  pause_on_click: true,       // pauses/continues typing on click/tap (elm) [default:false]
  pause_on_tab_switch: true,  // pauses typing if window is inactive (Page Visibility API) [default:false]
  
  // init callback (ready-to-type)
  init:function(elm){},        
  // typing callback
  typing:function(elm,chr_or_elm,left,total){},
  // finished callback
  fin:function(elm){}          
 
 });

});

</script>

</html>