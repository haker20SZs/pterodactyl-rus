<?php

    $config = [

    	"name" => "WestalBot",
    	"url_tg" => "https://t.me/WestalHost_Bot",
        "url_gitbook" => "https://westalhost.gitbook.io/",
    	"url_home" => "https://whost.su/",
    	"suma" => "650",
    	"secret_word" => "da84nqdat",
        
        "pay" => [

            "tg" => "https://t.me/zlogger_pro",
            "vk" => "https://vk.com/love_2077",

        ],

    ];

?>