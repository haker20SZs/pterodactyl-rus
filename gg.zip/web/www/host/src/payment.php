<?php

    class payment {

    	var $config;

    	function __construct ($config) {

    		$this->config = $config;

    	}

    	function send($tg, $form, $pay) {

            include './config.php';
            include __DIR__ . '/../../api/tg/config.php';

            $url = "https://api.telegram.org/bot" . $get_config['token'] . "/getChatMember?chat_id=" . $tg . "&user_id=" . $tg;

            $ch = curl_init($url);

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            $data = json_decode($response, true);

            $url = ((!empty($_SERVER['HTTPS'])) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

            if ($data['result']['user']['username'] == null and $data['result']['user']['username'] == "") {

                header("Location: " . $url);

                exit();

                return false;

            }
            
            function onEncode($text, $key, $cipher) {

                $ivlen = openssl_cipher_iv_length($cipher);
                $iv = openssl_random_pseudo_bytes($ivlen);
                $raw = openssl_encrypt($text, $cipher, $key, $options = OPENSSL_RAW_DATA, $iv);
                $hmac = hash_hmac('sha256', $raw, $key, $as_binary = true);
                $encode = base64_encode($iv . $hmac . $raw);

                return $encode;

            }

            $array = [

                "id" => $tg,
                "key" => $config['secret_word'],
                "suma" => $config['suma'],
                "receiver_id" => "",
                "telegram_id" => "6080490144",
                "gidpay_id" => "127",
                "gidpay_key" => "MIupJiTijo0kMxPw",
                "aaio_id" => "e04d5975-9c90-4937-a608-447850c5ef5a",
                "aaio_secret" => "a6d6da49f3f328ead8f4a884091d6ede",
                "url_app" => $url,

            ];

            $data = onEncode(json_encode($array), $config['secret_word'], "AES-128-CBC");

            header("Location: https://paynel.ru/?data=" . base64_encode($data), true, 302);

            exit();

    	}

    }

?>