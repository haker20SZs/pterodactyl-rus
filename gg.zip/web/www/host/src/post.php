<?php

    include "./src/payment.php";

    $payment = new payment($config);

    if (isset($_POST['buy'])) {
        
    	$payment->send($_POST['tg'], $_POST['form'], $_POST['pay']);

    }

?>