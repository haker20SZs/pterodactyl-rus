<?php

    header('Content-Type: application/json');

    include 'config.php';

    date_default_timezone_set('Asia/Krasnoyarsk');

    $currentTime = date('H:i');

    if ($currentTime >= $get_config['time_start'] && $currentTime <= $get_config['time_stop']) {

        $name_bot = "🛡 - DDoS атаки :: L3/L4 - Online";

        print_R (

            json_encode (

                array (

                    "response" => true,

                ),

            ),

        );

    } else {

        $name_bot = "📛 - DDoS атаки :: L3/L4 - Offline";

        print_R (

            json_encode (

                array (

                    "response" => false,

                ),

            ),

        );

    }

    $response = shell_exec("curl https://api.telegram.org/bot" . $get_config['token'] . "/getMe 2>/dev/null");

    $responseData = json_decode($response, true);

    if ($name_bot == $responseData['result']['first_name']) {

        return true;

    }

    $response = shell_exec("curl -d 'name={$name_bot}' https://api.telegram.org/bot" . $get_config['token'] . "/setMyName 2>/dev/null");

    $responseData = json_decode($response, true);

    if ($responseData['ok']) {

    	print_R (

            array (

                "text" => "Название чата изменено на: " . $name_bot . "\n"

            ),

        );

    } else {

    	print_R (

            array (

                "text" => "Ошибка изменения названия чата: " . $responseData['description'] . "\n"

            ),

        );

    }

?>