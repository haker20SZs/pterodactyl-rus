<?php

    # Помощь:
    // - /help :: /help admin 

    $get_config = [

        "tag" => "(:TG:)",
        "token" => "7156853164:AAEouJJPksiXAIPSTHd468YXUw1-phY5Zow",
        "key" => "da84nqdat", //Ключ проверки для бота
        "users_file" => "users.json",
        "block_file" => "blocks.json",
        "botnet_file" => "botnet.json",
        "url" => "https://whost.su/",
        "tg" => "https://t.me/zlogger_pro",
        "help_url" => "https://search.censys.io/",
        "max_time" => 300,
        "time_start" => "07:00",
        "time_stop" => "23:00",

        "methods" => array (

            "UDP",
            "OVH",
            "HOME",
            "STRESSER",
            "AMP",
            
        ),

        "company" => array (
            
            "DigitalOcean, LLC",
            "Tristan Fischer trading as oneCorp Systems",
            "Castles LLC",
            "SBERCLOUD NET",

        ),

        "admin_ids" => array (

            "6080490144",

        ),

        "wl_ids" => array (

            "7265983090",

        ),

    ];

?>