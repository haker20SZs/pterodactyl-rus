<?php
    
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    class tgBot {

        private $token = '';

        public function __construct($token) {

            $this->token = $token;

        }

        public function request($method, $params = []) {

            $url = 'https://api.telegram.org/bot' . $this->token .  '/' . $method;
            $curl = curl_init();

            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $params);

            $out = json_decode(curl_exec($curl), true);

            curl_close($curl);

            return $out;

        }

        public function reply($chat, $text) {

            $a = $this->request('sendMessage', ["parse_mode" => "html", "chat_id" => $chat, "text" => $text]);

            return $a;

        }

        public function sendButtonWebApp($chat, $text, $webAppUrl, $text_button) {

            $keyboard = [

                'inline_keyboard' => [

                    [
                        [

                            'text' => "$text_button",
                            'web_app' => [

                                'url' => "$webAppUrl"

                            ]

                        ]

                    ]

                ]

            ];

            $a = $this->request('sendMessage', ["parse_mode" => "html", "chat_id" => $chat, "text" => $text, "reply_markup" => json_encode($keyboard)]);

            return $a;

        }

        public function sticker($chat, $sticker) {

            $a = $this->request('sendSticker', ["chat_id" => $chat, "sticker" => $sticker]);

            return $a;

        }

        public function pictureReply($chat, $text, $url_of_picture) {

            $a = $this->request('sendPhoto', ["parse_mode" => "markdown", "chat_id" => $chat, "caption" => $text, "photo" => $url_of_picture]);

            return $a;

        }

        public function sendPhotoMessageButtonURL($chat, $text, $text_button, $url, $photo_url) {

            $a = $this->request('sendPhoto', ["chat_id" => $chat, "photo" => $photo_url, "caption" => $text, "parse_mode" => "html", 'reply_markup' => json_encode (

                array (

                    'inline_keyboard' => array (

                        array (

                            array (

                                'text' => $text_button,
                                'url' => $url,

                            ),

                        ),

                    ),

                ),

            )]);

            return $a;

        }

        public function sendMessageButtonURL($chat, $text, $text_button, $url) {

            $a = $this->request('sendMessage', ["chat_id" => $chat, "text" => $text, "parse_mode" => "html", 'reply_markup' => json_encode (

                array (

                    'inline_keyboard' => array (

                        array (

                            array (

                                'text' => $text_button,
                                'url' => $url,

                            ),

                        ),

                    ),

                ),

            )]);

            return $a;

        }

    }

?>