<?php

    include __DIR__ . '/../config.php';

    $fileContents = file_get_contents(__DIR__ . "/json/" . $get_config['users_file']);

    $data = json_decode($fileContents, true);

    if (!empty($data)) {

    	foreach ($data as $key => $value) {

    		if (!empty($value) && !empty($key)) {

                $currentDate = date("Y-m-d");

                $currentTimestamp = strtotime($currentDate);
                $startTimestamp = strtotime($value['date']);

                if ($currentTimestamp >= $startTimestamp) {

                    if (isset($data[$key])) {

                        unset($data[$key]);

                        $newFileContents = json_encode($data, JSON_PRETTY_PRINT);

                        file_put_contents(__DIR__ . "/json/" . $get_config['users_file'], $newFileContents);

                    }

                    return false;

                }

    		}

    	}

    }

?>