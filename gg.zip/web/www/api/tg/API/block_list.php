<?php

    include __DIR__ . '/../config.php';

    header('Content-Type: application/json');

    $ip = isset($_POST['ip']) ? $_POST['ip'] : '';
    $method = isset($_POST['method']) ? $_POST['method'] : '';
    $key = isset($_POST['key']) ? $_POST['key'] : '';

    if ($key == $get_config['key']) {

        if ($method == 'del') {

            $fileContents = file_get_contents("json/" . $get_config['block_file']);

            $config = json_decode($fileContents, true);

            if (isset($config[$ip])) {

                if ($ip == null and $ip == "") {

                    print_R (

                        json_encode (

                            array (

                                "message" => "Нельзя использовать пустые строки в IP",

                            ),

                        )

                    );

                    return false;

                } else if (!(filter_var($ip, FILTER_VALIDATE_IP))) {

                    print_R (

                        json_encode (

                            array (

                                "message" => "Нельзя использовать буквы или спецсимволы в IP",

                            ),

                        )

                    );

                    return false;

                } else {

                    unset($config[$ip]);

                    $newFileContents = json_encode($config);

                    file_put_contents("json/" . $get_config['block_file'], $newFileContents);

                    print_R (

                        json_encode (

                            array (

                                "message" => "Айпи адерс успешно удален из базы",

                            ),

                        )

                    );

                    return false;

                }

            } else {

                print_R (

                    json_encode (

                        array (

                            "message" => "Айпи адрес не найден в базе",

                        ),

                    )

                );

                return false;

            }

        } elseif ($method == 'add') {

            if ($ip == null and $ip == "") {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать пустые строки в IP",

                        ),

                    )

                );

                return false;

            } else if (!(filter_var($ip, FILTER_VALIDATE_IP))) {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать буквы или спецсимволы в IP",

                        ),

                    )

                );

                return false;

            } else if (!(filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE))) {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать локальный IP адрес",

                        ),

                    )

                );

                return false;

            } else {

                $fileContents = file_get_contents("json/" . $get_config['block_file']);

                $config = json_decode($fileContents, true);

                foreach ($config as $get_ip => $info) {

                    if ($get_ip == $ip) {

                        print_R (

                            json_encode (

                                array (

                                    "message" => "Данный айпи адрес уже в базе",

                                ),

                            )

                        );

                        return true;

                    }

                }

                $url = "http://ip-api.com/json/" . $ip;

                $ch = curl_init();

                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                $response = curl_exec($ch);

                $data = json_decode($response, true);

                $org = isset($data['org']) && !empty($data['org']) ? $data['org'] : "Не найдена";

                curl_close($ch);

                $config[$ip] = $org;

                $newFileContents = json_encode($config);

                file_put_contents("json/" . $get_config['block_file'], $newFileContents);

                print_R (

                    json_encode (

                        array (

                            "message" => "Айпи успешно добавлен в базу",

                        ),

                    )

                );

                return false;

            }

        } elseif ($method == 'list') {

            $fileContents = file_get_contents("json/" . $get_config['block_file']);

            $data = json_decode($fileContents, true);

            if (!empty($data)) {

                foreach ($data as $key => $value) {

                    if (!empty($value) || !empty($key)) {

                        $output .= "$key -> $value.\n";

                    }

                }

                print_R($output);

            } else {

                print_R (

                    json_encode (

                        array (

                            "message" => "Айпи адресов не найдено",

                        ),

                    )

                );

                return false;

            }

        } else {

            print_R (

                json_encode (

                    array (

                        "message" => "Недопустимый метод",

                    ),

                )

            );

            return false;

        }

    } else {

        print_R (

            json_encode (

                array (

                    "message" => "Не найден ключ или введен неверно",

                ),

            )

        );

        return false;

    }

?>