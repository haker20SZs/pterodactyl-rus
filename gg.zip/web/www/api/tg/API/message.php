<?php

    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
    header("Content-type: application/json; charset=utf-8");

    include '../config.php';

    if ($_POST['key'] == $get_config['key']) {

        if (!($_POST['text'])) {

            print_R (

                array (

                    "message" => "Не задан параметр - text."

                ),

            );

            return false;

        } else {

            $message = $_POST['text'];

        }

        if (!($_POST['id'])) {

            print_R (

                array (

                    "message" => "Не задан параметр - id."

                ),

            );

            return false;

        } else if ($_POST['id'] == "all") {

            $fileContents = file_get_contents(__DIR__ . "/json/" . $get_config['users_file']);
            $data = json_decode($fileContents, true);

            foreach ($data as $key => $value) {

                $url = "https://api.whost.su/tg/API/message.php";

                $array = array (

                    "id" => $key,
                    "text" => $message,
                    "key" => $get_config['key'],

                );

                $ch = curl_init();

                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $array);

                curl_exec($ch);

                curl_close($ch);

            }

            return true;

        } else if (!(is_numeric($_POST['id']))) {

            print_R (

                array (

                    "message" => "Параметр id может содержать только цифры."

                ),

            );

            return false;

        } else {

            $chatId = $_POST['id'];

        }

        $data = array (

            'parse_mode' => "html",
            'chat_id' => $chatId,
            'text' => $message,

        );

        $options = array  (

            'http' => array (

                'method' => 'POST',
                'header' => 'Content-type: application/x-www-form-urlencoded',
                'content' => http_build_query($data)

            )

        );

        $context = stream_context_create($options);
        $result = file_get_contents("https://api.telegram.org/bot" . $get_config['token'] . "/sendMessage", false, $context);

        if (!($result === false)) {

            print_R (

                array (

                    "message" => "Сообщение успешно отправлено в Telegram."

                ),

            );

            return true;

        }

    } else {

        print_R (

            array (

                "message" => "Неправильно задан параметр - key."

            ),

        );

        return false;

    }

?>