<?php

    include __DIR__ . '/../config.php';

    header('Content-Type: application/json');

    $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
    $method = isset($_POST['method']) ? $_POST['method'] : '';
    $key = isset($_POST['key']) ? $_POST['key'] : '';

    function gen_token($length = 6) {

        $token = '';

        $arr = array (

            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
            'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
            'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
            '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'

        );

        for ($i = 0; $i < $length; $i++) {

            $token .= $arr[random_int(0, count($arr) - 1)];

        }

        return $token;

    }

    if ($key == $get_config['key']) {

        if ($method == 'del') {

            $fileContents = file_get_contents("json/" . $get_config['users_file']);

            $config = json_decode($fileContents, true);

            if (isset($config[$user_id])) {

                if ($user_id == null and $user_id == "") {

                    print_R (

                        json_encode (

                            array (

                                "message" => "Нельзя использовать пустые строки в user_id",

                            ),

                        )

                    );

                    return false;

                } elseif (!(is_numeric($user_id))) {

                    print_R (

                        json_encode (

                            array (

                                "message" => "Нельзя использовать буквы или спецсимволы в user_id",

                            ),

                        )

                    );

                    return false;

                } else {

                    unset($config[$user_id]);

                    $newFileContents = json_encode($config, JSON_PRETTY_PRINT);

                    file_put_contents("json/" . $get_config['users_file'], $newFileContents);

                    print_R (

                        json_encode (

                            array (

                                "message" => "Айди успешно удален из базы",

                            ),

                        )

                    );

                    return true;

                }

            } else {

                print_R (

                    json_encode (

                        array (

                            "message" => "Айди не найден в базе",

                        ),

                    )

                );

                return false;

            }

        } elseif ($method == 'add') {

            if ($user_id == null and $user_id == "") {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать пустые строки в user_id",

                        ),

                    )

                );

                return false;

            } elseif (!(is_numeric($user_id))) {

                print_R (

                    json_encode (

                        array (

                            "message" => "Нельзя использовать буквы или спецсимволы в user_id",

                        ),

                    )

                );

                return false;

            } else {

                $fileContents = file_get_contents("json/" . $get_config['users_file']);

                $config = json_decode($fileContents, true);

                $url = "https://api.telegram.org/bot" . $get_config['token'] . "/getChatMember?chat_id=" . $user_id . "&user_id=" . $user_id;

                $ch = curl_init();

                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                $response = curl_exec($ch);

                $data = json_decode($response, true);

                $get_username = $data['result']['user']['username'];

                curl_close($ch);

                foreach ($config as $get_id => $info) {

                    if ($get_id == $user_id) {

                        print_R (

                            json_encode (

                                array (

                                    "message" => "Данный айди уже в базе",

                                ),

                            )

                        );

                        return false;

                    }

                }

                if ($get_username == null) {

                    print_R (

                        json_encode (

                            array (

                                "message" => "Не удалось найти пользователя",

                            ),

                        )

                    );

                    return false;

                }

                $date = date("d-m-Y", strtotime("+1 month"));

                $config[$user_id] = array (

                    "username" => $get_username,
                    "token" => gen_token(16),
                    "date" => $date,

                );

                $newFileContents = json_encode($config, JSON_PRETTY_PRINT);

                file_put_contents("json/" . $get_config['users_file'], $newFileContents);

                print_R (

                    json_encode (

                        array (

                            "message" => "Айди успешно добавлен в базу",

                        ),

                    )

                );

                return true;

            }

        } elseif ($method == 'list') {

            $fileContents = file_get_contents("json/" . $get_config['users_file']);

            $data = json_decode($fileContents, true);
            
            if (!empty($data)) {

                foreach ($data as $key => $value) {

                    if (!empty($value) && !empty($key)) {

                        $output .= $value['username'] . " -> " . $value['date'] . ".\n";

                    }

                }

                print_R($output);

                return true;

            } else {

                print_R (

                    json_encode (

                        array (

                            "message" => "Пользователей не найдено",

                        ),

                    )

                );

                return false;

            }

        } else {

            print_R (

                json_encode (

                    array (

                        "message" => "Недопустимый метод",

                    ),

                )

            );

            return false;

        }

    } else {

        print_R (

            json_encode (

                array (

                    "message" => "Не найден ключ или введен неверно",

                ),

            )

        );

        return false;

    }

?>