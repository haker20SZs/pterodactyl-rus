<?php

return [
    'search' => 'Поиск серверов...',
    'no_matches' => 'Не найдены сервера подходящие по данному поиску.',
    'cpu_title' => 'CPU',
    'memory_title' => 'Память',
];
